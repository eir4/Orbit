import Foundation

/// Selects the attachment represented by the conversation's context panel.
public enum ConversationAttachmentPanel {
    public static func preferred(
        pending: [PreparedAttachment],
        current: [PreparedAttachment]
    ) -> PreparedAttachment? {
        pending.first ?? current.first
    }
}

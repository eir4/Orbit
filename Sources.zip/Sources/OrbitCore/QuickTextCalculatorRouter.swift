import Foundation

/// Routes bare arithmetic entered for the lightweight Quick text model to the local calculator.
public enum QuickTextCalculatorRouter {
    public static func answer(model: LocalModel, prompt: String) throws -> String? {
        let isQuickText = model.role.caseInsensitiveCompare("Quick text") == .orderedSame
            || model.id.lowercased().contains("lfm2.5")
        guard isQuickText else { return nil }

        let trimmed = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard isBareArithmetic(trimmed) else { return nil }
        let normalized = trimmed
            .replacingOccurrences(of: "×", with: "*")
            .replacingOccurrences(of: "÷", with: "/")
        return try BasicCalculatorTool().execute(arguments: ["expression": .string(normalized)])
    }

    private static func isBareArithmetic(_ prompt: String) -> Bool {
        guard !prompt.isEmpty, prompt.count <= 256 else { return false }
        let allowed = CharacterSet(charactersIn: "0123456789 .+-*/^()×÷")
        guard prompt.unicodeScalars.allSatisfy(allowed.contains) else { return false }
        return prompt.contains(where: { "+-*/^×÷".contains($0) })
    }
}

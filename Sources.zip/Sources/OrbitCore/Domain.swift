import Foundation

public struct LocalModel: Codable, Hashable, Identifiable, Sendable {
    public let id: String
    public let ownedBy: String
    public var role: String

    public init(id: String, ownedBy: String = "local", role: String = "General") {
        self.id = id
        self.ownedBy = ownedBy
        self.role = role
    }

    public var displayName: String {
        id.replacingOccurrences(of: "-", with: " ")
            .replacingOccurrences(of: "_", with: " ")
            .capitalized
    }
}

public enum AttachmentKind: String, Codable, Sendable {
    case text
    case image
    case pdf
    case hex
    case other

    public static func infer(fileExtension: String) -> AttachmentKind {
        switch fileExtension.lowercased() {
        case "txt", "md", "rtf", "csv", "json", "yaml", "yml", "swift", "py", "js", "ts", "html", "xml", "log", "ipynb": .text
        case "png", "jpg", "jpeg", "gif", "webp", "heic", "tif", "tiff", "bmp": .image
        case "pdf": .pdf
        case "hex", "bin", "dat", "rom", "romfs", "fw", "img": .hex
        default: .other
        }
    }
}

public enum HexFormatter {
    public static func preview(_ data: Data, maxBytes: Int = 4_096, bytesPerRow: Int = 16) -> String {
        let bytes = Array(data.prefix(max(0, maxBytes)))
        guard !bytes.isEmpty else { return "(empty file)" }
        let width = max(1, bytesPerRow)
        return stride(from: 0, to: bytes.count, by: width).map { start in
            let row = Array(bytes[start..<min(start + width, bytes.count)])
            let hex = row.map { String(format: "%02X", $0) }.joined(separator: " ")
            let padding = String(repeating: "   ", count: width - row.count)
            let ascii = String(row.map { byte -> Character in
                (32...126).contains(byte) ? Character(UnicodeScalar(byte)) : "."
            })
            return String(format: "%08X  %@%@  |%@|", start, hex, padding, ascii)
        }.joined(separator: "\n")
    }
}

public struct PreparedAttachment: Codable, Sendable, Identifiable {
    public let id: UUID
    public let name: String
    public let kind: AttachmentKind
    public let summary: String
    public let text: String
    public let imageDataURL: String?
    public let byteCount: Int

    public init(id: UUID = UUID(), name: String, kind: AttachmentKind, summary: String, text: String = "", imageDataURL: String? = nil, byteCount: Int = 0) {
        self.id = id
        self.name = name
        self.kind = kind
        self.summary = summary
        self.text = text
        self.imageDataURL = imageDataURL
        self.byteCount = byteCount
    }
}

public struct SpecialistTask: Codable, Sendable, Equatable {
    public let modelID: String
    public let task: String

    public init(modelID: String, task: String) {
        self.modelID = modelID
        self.task = task
    }
}

public enum OrchestrationEvent: Sendable, Equatable {
    case mainThinking
    case delegated(modelID: String, task: String)
    case specialistResult(modelID: String, result: String)
    case completed(String)
}

public protocol ModelClient: Sendable {
    func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String
}

public enum OrchestratorError: LocalizedError, Equatable {
    case malformedDirective
    case unknownWorker(String)
    case workerLimitReached
    case emptyCoordinatorResponse

    public var errorDescription: String? {
        switch self {
        case .malformedDirective: "The coordinator returned an unsupported instruction."
        case .unknownWorker(let modelID): "The coordinator selected an unavailable specialist: \(modelID)."
        case .workerLimitReached: "The coordinator reached Orbit's specialist-turn limit."
        case .emptyCoordinatorResponse: "The coordinator returned an empty response after a retry, and no specialist was available to continue."
        }
    }
}

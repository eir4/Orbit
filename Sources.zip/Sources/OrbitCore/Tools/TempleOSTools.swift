import Foundation

public struct TempleOSMusicNotesTool: OrbitTool {
    private static let scales: [String: [Int]] = [
        "major": [0, 2, 4, 5, 7, 9, 11, 12],
        "minor": [0, 2, 3, 5, 7, 8, 10, 12],
        "pentatonic": [0, 2, 4, 7, 9, 12],
        "blues": [0, 3, 5, 6, 7, 10, 12]
    ]
    private static let noteNames = ["C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"]
    private static let rootSemitones: [String: Int] = [
        "C": 0, "B#": 0,
        "C#": 1, "DB": 1,
        "D": 2,
        "D#": 3, "EB": 3,
        "E": 4, "FB": 4,
        "F": 5, "E#": 5,
        "F#": 6, "GB": 6,
        "G": 7,
        "G#": 8, "AB": 8,
        "A": 9,
        "A#": 10, "BB": 10,
        "B": 11, "CB": 11
    ]

    public init() {}

    public var descriptor: OrbitToolDescriptor {
        OrbitToolDescriptor(
            name: "templeos_music_notes",
            description: "Compose a short local melody as note names. Optional root (C–B with #/b), scale (major, minor, pentatonic, blues), count (4–16), tempo (40–180 BPM), and seed; a seed makes the melody repeatable. This generates notation only and does not play audio.",
            inputSchema: #"{"type":"object","properties":{"root":{"type":"string"},"scale":{"type":"string","enum":["major","minor","pentatonic","blues"]},"count":{"type":"integer","minimum":4,"maximum":16},"tempo":{"type":"integer","minimum":40,"maximum":180},"seed":{"type":"integer","minimum":0}},"additionalProperties":false}"#
        )
    }

    public func execute(arguments: [String: JSONValue]) throws -> String {
        let root = (arguments["root"]?.stringValue ?? "C").uppercased()
        guard let rootSemitone = Self.rootSemitones[root] else {
            throw OrbitToolError.invalidArgument("root must be a note from C through B, with optional # or b")
        }
        let scaleName = (arguments["scale"]?.stringValue ?? "major").lowercased()
        guard let offsets = Self.scales[scaleName] else {
            throw OrbitToolError.invalidArgument("scale must be major, minor, pentatonic, or blues")
        }
        let count = try Self.integerArgument("count", in: arguments, default: 8, range: 4...16)
        let tempo = try Self.integerArgument("tempo", in: arguments, default: 96, range: 40...180)
        let seed = try Self.seedArgument(in: arguments)
        var random = TempleOSSeededGenerator(seed: seed)
        let baseMIDI = 60 + rootSemitone
        var notes: [String] = []
        for index in 0..<count {
            let degree = index == 0 ? 0 : Int.random(in: 0..<offsets.count, using: &random)
            let octaveLift = index == 0 ? 0 : Int.random(in: 0...1, using: &random) * 12
            notes.append(Self.noteName(midi: baseMIDI + offsets[degree] + octaveLift))
        }
        return "TempleOS music notes · root=\(root) · scale=\(scaleName) · tempo=\(tempo) BPM · seed=\(seed)\n" + notes.joined(separator: " ")
    }

    private static func noteName(midi: Int) -> String {
        let pitch = ((midi % 12) + 12) % 12
        let octave = midi / 12 - 1
        return noteNames[pitch] + String(octave)
    }

    private static func integerArgument(
        _ name: String,
        in arguments: [String: JSONValue],
        default defaultValue: Int,
        range: ClosedRange<Int>
    ) throws -> Int {
        guard let value = arguments[name] else { return defaultValue }
        guard case .number(let number) = value,
              number.isFinite,
              number.rounded() == number,
              number >= Double(range.lowerBound),
              number <= Double(range.upperBound) else {
            throw OrbitToolError.invalidArgument("\(name) must be an integer from \(range.lowerBound) through \(range.upperBound)")
        }
        return Int(number)
    }

    private static func seedArgument(in arguments: [String: JSONValue]) throws -> UInt64 {
        guard let value = arguments["seed"] else {
            var random = SystemRandomNumberGenerator()
            return random.next() & 0x1F_FFFF_FFFF_FFFF
        }
        guard case .number(let number) = value,
              number.isFinite,
              number.rounded() == number,
              number >= 0,
              number <= 9_007_199_254_740_991 else {
            throw OrbitToolError.invalidArgument("seed must be a non-negative safe integer")
        }
        return UInt64(number)
    }
}

public struct TempleOSGodWordTool: OrbitTool {
    private static let words = [
        "AMEN", "COMPASSION", "COVENANT", "FAITH", "FORGIVENESS", "GLORY", "GRACE", "HEALING",
        "HOPE", "JOY", "JUSTICE", "LIGHT", "LOVE", "MERCY", "PATIENCE", "PEACE", "PRAISE",
        "PROMISE", "REDEMPTION", "REFUGE", "RENEWAL", "REVELATION", "SHELTER", "STRENGTH",
        "TRUTH", "WISDOM", "WONDER", "WORSHIP", "ZION", "SELAH", "SHALOM", "HOSANNA"
    ]

    public init() {}

    public var descriptor: OrbitToolDescriptor {
        OrbitToolDescriptor(
            name: "templeos_god_word",
            description: "Pick 1–5 random words from a local TempleOS-inspired contemplative word list. An optional seed makes the result repeatable; this is a playful word picker, not a claim of divine meaning.",
            inputSchema: #"{"type":"object","properties":{"count":{"type":"integer","minimum":1,"maximum":5},"seed":{"type":"integer","minimum":0}},"additionalProperties":false}"#
        )
    }

    public func execute(arguments: [String: JSONValue]) throws -> String {
        let count = try Self.integerArgument("count", in: arguments, default: 1)
        let seed = try Self.seedArgument(in: arguments)
        var random = TempleOSSeededGenerator(seed: seed)
        var pool = Self.words
        var chosen: [String] = []
        for _ in 0..<count {
            let index = Int.random(in: 0..<pool.count, using: &random)
            chosen.append(pool.remove(at: index))
        }
        let label = count == 1 ? "TempleOS God word" : "TempleOS God words"
        return "\(label) · seed=\(seed): " + chosen.joined(separator: ", ")
    }

    private static func integerArgument(_ name: String, in arguments: [String: JSONValue], default defaultValue: Int) throws -> Int {
        guard let value = arguments[name] else { return defaultValue }
        guard case .number(let number) = value,
              number.isFinite,
              number.rounded() == number,
              number >= 1,
              number <= 5 else {
            throw OrbitToolError.invalidArgument("count must be an integer from 1 through 5")
        }
        return Int(number)
    }

    private static func seedArgument(in arguments: [String: JSONValue]) throws -> UInt64 {
        guard let value = arguments["seed"] else {
            var random = SystemRandomNumberGenerator()
            return random.next() & 0x1F_FFFF_FFFF_FFFF
        }
        guard case .number(let number) = value,
              number.isFinite,
              number.rounded() == number,
              number >= 0,
              number <= 9_007_199_254_740_991 else {
            throw OrbitToolError.invalidArgument("seed must be a non-negative safe integer")
        }
        return UInt64(number)
    }
}

private struct TempleOSSeededGenerator: RandomNumberGenerator {
    private var state: UInt64

    init(seed: UInt64) { state = seed }

    mutating func next() -> UInt64 {
        state &+= 0x9E37_79B9_7F4A_7C15
        var value = state
        value = (value ^ (value >> 30)) &* 0xBF58_476D_1CE4_E5B9
        value = (value ^ (value >> 27)) &* 0x94D0_49BB_1331_11EB
        return value ^ (value >> 31)
    }
}

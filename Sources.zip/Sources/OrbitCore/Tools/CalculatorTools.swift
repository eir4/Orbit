import Foundation

public struct BasicCalculatorTool: OrbitTool {
    public init() {}

    public var descriptor: OrbitToolDescriptor {
        OrbitToolDescriptor(
            name: "calculator",
            description: "Evaluate arithmetic with +, -, *, /, ^, parentheses, and real numbers.",
            inputSchema: #"{"expression":"arithmetic expression"}"#
        )
    }

    public func execute(arguments: [String: JSONValue]) throws -> String {
        guard let expression = arguments["expression"]?.stringValue else {
            throw OrbitToolError.missingArgument("expression")
        }
        var parser = ExpressionParser(expression: expression, scientific: false)
        return format(try parser.evaluate())
    }
}

public struct ScientificCalculatorTool: OrbitTool {
    public init() {}

    public var descriptor: OrbitToolDescriptor {
        OrbitToolDescriptor(
            name: "scientific_calculator",
            description: "Evaluate scientific expressions in radians; supports sin, cos, tan, inverse trig, sqrt, ln, log10, exp, abs, pow, min, max, pi, and e.",
            inputSchema: #"{"expression":"scientific expression"}"#
        )
    }

    public func execute(arguments: [String: JSONValue]) throws -> String {
        guard let expression = arguments["expression"]?.stringValue else {
            throw OrbitToolError.missingArgument("expression")
        }
        var parser = ExpressionParser(expression: expression, scientific: true)
        return format(try parser.evaluate())
    }
}

private func format(_ value: Double) -> String {
    String(format: "%.12g", locale: Locale(identifier: "en_US_POSIX"), value == 0 ? 0 : value)
}

private struct ExpressionParser {
    private let characters: [Character]
    private let scientific: Bool
    private var index = 0

    init(expression: String, scientific: Bool) {
        characters = Array(expression)
        self.scientific = scientific
    }

    mutating func evaluate() throws -> Double {
        guard !characters.isEmpty, characters.count <= 256 else { throw OrbitToolError.invalidExpression }
        let value = try parseAdditive()
        skipWhitespace()
        guard index == characters.count else { throw OrbitToolError.invalidExpression }
        guard value.isFinite else { throw OrbitToolError.invalidDomain }
        return value
    }

    private mutating func parseAdditive() throws -> Double {
        var value = try parseMultiplicative()
        while true {
            if consume("+") { value += try parseMultiplicative() }
            else if consume("-") { value -= try parseMultiplicative() }
            else { return value }
            guard value.isFinite else { throw OrbitToolError.invalidDomain }
        }
    }

    private mutating func parseMultiplicative() throws -> Double {
        var value = try parseUnary()
        while true {
            if consume("*") { value *= try parseUnary() }
            else if consume("/") {
                let divisor = try parseUnary()
                guard divisor != 0 else { throw OrbitToolError.divisionByZero }
                value /= divisor
            } else { return value }
            guard value.isFinite else { throw OrbitToolError.invalidDomain }
        }
    }

    private mutating func parseUnary() throws -> Double {
        if consume("+") { return try parseUnary() }
        if consume("-") { return -(try parseUnary()) }
        return try parsePower()
    }

    private mutating func parsePower() throws -> Double {
        let base = try parsePrimary()
        guard consume("^") else { return base }
        let exponent = try parseUnary()
        let value = Foundation.pow(base, exponent)
        guard value.isFinite else { throw OrbitToolError.invalidDomain }
        return value
    }

    private mutating func parsePrimary() throws -> Double {
        skipWhitespace()
        guard index < characters.count else { throw OrbitToolError.invalidExpression }
        if consume("(") {
            let value = try parseAdditive()
            guard consume(")") else { throw OrbitToolError.invalidExpression }
            return value
        }
        if isDigit(current) || current == "." { return try parseNumber() }
        if isIdentifierStart(current) { return try parseIdentifierOrFunction() }
        throw OrbitToolError.invalidExpression
    }

    private mutating func parseNumber() throws -> Double {
        let start = index
        var digits = 0
        while index < characters.count, isDigit(current) { index += 1; digits += 1 }
        if index < characters.count, current == "." {
            index += 1
            while index < characters.count, isDigit(current) { index += 1; digits += 1 }
        }
        guard digits > 0 else { throw OrbitToolError.invalidExpression }
        if index < characters.count, (current == "e" || current == "E") {
            index += 1
            if index < characters.count, (current == "+" || current == "-") { index += 1 }
            let exponentStart = index
            while index < characters.count, isDigit(current) { index += 1 }
            guard index > exponentStart else { throw OrbitToolError.invalidExpression }
        }
        guard let value = Double(String(characters[start..<index])), value.isFinite else { throw OrbitToolError.invalidExpression }
        return value
    }

    private mutating func parseIdentifierOrFunction() throws -> Double {
        let start = index
        while index < characters.count, isIdentifierCharacter(current) { index += 1 }
        let name = String(characters[start..<index]).lowercased()
        if scientific, name == "pi" { return Double.pi }
        if scientific, name == "e" { return M_E }
        guard scientific else { throw OrbitToolError.invalidExpression }
        guard consume("(") else { throw OrbitToolError.invalidExpression }
        var arguments: [Double] = []
        if !consume(")") {
            repeat {
                arguments.append(try parseAdditive())
                if consume(")") { break }
                guard consume(",") else { throw OrbitToolError.invalidExpression }
            } while true
        }
        let value: Double
        switch (name, arguments.count) {
        case ("sin", 1): value = Foundation.sin(arguments[0])
        case ("cos", 1): value = Foundation.cos(arguments[0])
        case ("tan", 1): value = Foundation.tan(arguments[0])
        case ("asin", 1), ("arcsin", 1): value = Foundation.asin(arguments[0])
        case ("acos", 1), ("arccos", 1): value = Foundation.acos(arguments[0])
        case ("atan", 1), ("arctan", 1): value = Foundation.atan(arguments[0])
        case ("sqrt", 1): value = Foundation.sqrt(arguments[0])
        case ("ln", 1): value = Foundation.log(arguments[0])
        case ("log", 1), ("log10", 1): value = Foundation.log10(arguments[0])
        case ("exp", 1): value = Foundation.exp(arguments[0])
        case ("abs", 1): value = Swift.abs(arguments[0])
        case ("pow", 2): value = Foundation.pow(arguments[0], arguments[1])
        case ("min", 2): value = Swift.min(arguments[0], arguments[1])
        case ("max", 2): value = Swift.max(arguments[0], arguments[1])
        default: throw OrbitToolError.invalidExpression
        }
        guard value.isFinite else { throw OrbitToolError.invalidDomain }
        return value
    }

    private var current: Character { characters[index] }

    private mutating func consume(_ character: Character) -> Bool {
        skipWhitespace()
        guard index < characters.count, current == character else { return false }
        index += 1
        return true
    }

    private mutating func skipWhitespace() {
        while index < characters.count, current.isWhitespace { index += 1 }
    }

    private func isDigit(_ character: Character) -> Bool { character >= "0" && character <= "9" }
    private func isIdentifierStart(_ character: Character) -> Bool { (character >= "a" && character <= "z") || (character >= "A" && character <= "Z") || character == "_" }
    private func isIdentifierCharacter(_ character: Character) -> Bool { isIdentifierStart(character) || isDigit(character) }
}

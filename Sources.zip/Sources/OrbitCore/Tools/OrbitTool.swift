import Foundation

public enum JSONValue: Codable, Equatable, Sendable {
    case object([String: JSONValue])
    case array([JSONValue])
    case string(String)
    case number(Double)
    case bool(Bool)
    case null

    public init(from decoder: Decoder) throws {
        if let container = try? decoder.container(keyedBy: DynamicCodingKey.self) {
            var values: [String: JSONValue] = [:]
            for key in container.allKeys {
                values[key.stringValue] = try container.decode(JSONValue.self, forKey: key)
            }
            self = .object(values)
            return
        }
        if var container = try? decoder.unkeyedContainer() {
            var values: [JSONValue] = []
            while !container.isAtEnd { values.append(try container.decode(JSONValue.self)) }
            self = .array(values)
            return
        }
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            self = .null
        } else if let value = try? container.decode(Bool.self) {
            self = .bool(value)
        } else if let value = try? container.decode(Double.self) {
            self = .number(value)
        } else if let value = try? container.decode(String.self) {
            self = .string(value)
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Unsupported JSON value")
        }
    }

    public func encode(to encoder: Encoder) throws {
        switch self {
        case .object(let values):
            var container = encoder.container(keyedBy: DynamicCodingKey.self)
            for (key, value) in values {
                guard let codingKey = DynamicCodingKey(stringValue: key) else { continue }
                try container.encode(value, forKey: codingKey)
            }
        case .array(let values):
            var container = encoder.unkeyedContainer()
            for value in values { try container.encode(value) }
        case .string(let value):
            var container = encoder.singleValueContainer()
            try container.encode(value)
        case .number(let value):
            var container = encoder.singleValueContainer()
            try container.encode(value)
        case .bool(let value):
            var container = encoder.singleValueContainer()
            try container.encode(value)
        case .null:
            var container = encoder.singleValueContainer()
            try container.encodeNil()
        }
    }

    public var stringValue: String? {
        if case .string(let value) = self { return value }
        return nil
    }

    public var arrayValue: [JSONValue]? {
        if case .array(let value) = self { return value }
        return nil
    }
}

private struct DynamicCodingKey: CodingKey {
    let stringValue: String
    var intValue: Int? { nil }

    init?(stringValue: String) { self.stringValue = stringValue }
    init?(intValue: Int) { stringValue = String(intValue) }
}

public struct OrbitToolDescriptor: Equatable, Sendable {
    public let name: String
    public let description: String
    public let inputSchema: String

    public init(name: String, description: String, inputSchema: String) {
        self.name = name
        self.description = description
        self.inputSchema = inputSchema
    }
}

public protocol OrbitTool: Sendable {
    var descriptor: OrbitToolDescriptor { get }
    func execute(arguments: [String: JSONValue]) throws -> String
}

public enum OrbitToolError: LocalizedError, Equatable {
    case duplicateName(String)
    case unknownTool(String)
    case missingArgument(String)
    case invalidArgument(String)
    case invalidExpression
    case divisionByZero
    case invalidDomain
    case invalidCanvas
    case toolCallLimitReached

    public var errorDescription: String? {
        switch self {
        case .duplicateName(let name): "A tool named \(name) is already registered."
        case .unknownTool(let name): "Tool not available: \(name)."
        case .missingArgument(let name): "Missing tool argument: \(name)."
        case .invalidArgument(let name): "Invalid tool argument: \(name)."
        case .invalidExpression: "The calculator could not parse that expression."
        case .divisionByZero: "Division by zero is not allowed."
        case .invalidDomain: "That expression is outside the calculator's real-number domain."
        case .invalidCanvas: "The ASCII canvas must contain 1–40 printable ASCII rows, each at most 80 characters."
        case .toolCallLimitReached: "The model exceeded the maximum tool calls for one response."
        }
    }
}

public struct ToolRegistry: Sendable {
    private let tools: [String: any OrbitTool]

    public init(tools: [any OrbitTool]) throws {
        var registered: [String: any OrbitTool] = [:]
        for tool in tools {
            let name = tool.descriptor.name
            guard registered[name] == nil else { throw OrbitToolError.duplicateName(name) }
            registered[name] = tool
        }
        self.tools = registered
    }

    public static let builtIn = try! ToolRegistry(tools: [
        BasicCalculatorTool(),
        ScientificCalculatorTool(),
        ASCIICanvasTool(),
        TempleOSMusicNotesTool()
    ])

    public var descriptors: [OrbitToolDescriptor] {
        tools.values.map(\.descriptor).sorted { $0.name < $1.name }
    }

    public var modelInstructions: String {
        let catalog = descriptors.map {
            "- \($0.name): \($0.description)\n  input: \($0.inputSchema)"
        }.joined(separator: "\n")
        return """
        Approved local tools:
        \(catalog)

        Special case: ascii_canvas needs the rows argument as an array of literal text rows, not a description of the drawing. It accepts up to 80 rows and 256 characters per row, including printable ASCII and Unicode box/block symbols. Do not use an `input` field for `ascii_canvas`.
        For a smiley or kaomoji, answer directly without `ascii_canvas`. Use `ascii_canvas` only for multi-line or structured text art, and do not repeat an identical tool call after receiving its result.

        To call a tool, emit exactly one JSON object and nothing else:
        {"tool_call":"tool_name","arguments":{...}}
        The tool result will be returned to you; then continue the response. Only the listed tools are available. Do not claim a tool ran unless you receive its result. After a successful calculator call, use that result and answer; do not call the calculator again for the same expression.
        """
    }

    public func execute(name: String, arguments: [String: JSONValue]) throws -> String {
        guard let tool = tools[name] else { throw OrbitToolError.unknownTool(name) }
        return try tool.execute(arguments: arguments)
    }
}

public enum OrbitToolEvent: Equatable, Sendable {
    case invoked(name: String, arguments: String)
    case result(name: String, output: String)
}

/// Gives any ModelClient the same allowlisted, local-only tools through a simple JSON call protocol.
public struct ToolAwareModelClient: ModelClient {
    private let baseClient: any ModelClient
    private let registry: ToolRegistry
    private let maxToolCalls: Int
    private let onEvent: (@Sendable (OrbitToolEvent) async -> Void)?

    public init(
        baseClient: any ModelClient,
        registry: ToolRegistry = .builtIn,
        maxToolCalls: Int = 3,
        onEvent: (@Sendable (OrbitToolEvent) async -> Void)? = nil
    ) {
        self.baseClient = baseClient
        self.registry = registry
        self.maxToolCalls = max(0, maxToolCalls)
        self.onEvent = onEvent
    }

    public func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String {
        if images.isEmpty,
           let quickTextAnswer = try QuickTextCalculatorRouter.answer(
                model: LocalModel(id: modelID, role: ""),
                prompt: user
           ) {
            let argumentsText = (try? JSONEncoder.sorted.encode(JSONValue.object(["expression": .string(user.trimmingCharacters(in: .whitespacesAndNewlines))])))
                .flatMap { String(data: $0, encoding: .utf8) } ?? "{}"
            await onEvent?(.invoked(name: "calculator", arguments: argumentsText))
            await onEvent?(.result(name: "calculator", output: quickTextAnswer))
            return quickTextAnswer
        }

        let toolSystem = system + "\n\n" + registry.modelInstructions
        var context = user
        var callCount = 0
        var executedCalls: [String: String] = [:]
        while true {
            let response = try await baseClient.complete(modelID: modelID, system: toolSystem, user: context, images: images)
            guard let request = ToolCallRequest.parse(response) else { return response }
            let argumentsText = (try? JSONEncoder.sorted.encode(JSONValue.object(request.arguments)))
                .flatMap { String(data: $0, encoding: .utf8) } ?? "{}"
            let fingerprint = Self.toolCallFingerprint(name: request.name, arguments: request.arguments, encoded: argumentsText)
            if let priorResult = executedCalls[fingerprint] { return priorResult }
            guard callCount < maxToolCalls else { throw OrbitToolError.toolCallLimitReached }
            callCount += 1
            await onEvent?(.invoked(name: request.name, arguments: argumentsText))
            let result: String
            do {
                result = try registry.execute(name: request.name, arguments: request.arguments)
            } catch {
                result = "Tool error: \(error.localizedDescription)"
            }
            executedCalls[fingerprint] = result
            await onEvent?(.result(name: request.name, output: result))
            context += "\n\n[Orbit tool result name=\(request.name)]\n\(result)\n[End Orbit tool result]"
        }
    }

    private static func toolCallFingerprint(name: String, arguments: [String: JSONValue], encoded: String) -> String {
        guard name == "calculator" || name == "scientific_calculator",
              case .string(let expression)? = arguments["expression"] else {
            return name + "\n" + encoded
        }
        var normalized = arguments
        normalized["expression"] = .string(
            expression
                .filter { !$0.isWhitespace }
                .replacingOccurrences(of: "×", with: "*")
                .replacingOccurrences(of: "÷", with: "/")
        )
        let canonical = (try? JSONEncoder.sorted.encode(JSONValue.object(normalized)))
            .flatMap { String(data: $0, encoding: .utf8) } ?? encoded
        return name + "\n" + canonical
    }
}

private struct ToolCallRequest {
    let name: String
    let arguments: [String: JSONValue]

    static func parse(_ response: String) -> ToolCallRequest? {
        var candidate = response.trimmingCharacters(in: .whitespacesAndNewlines)
        if candidate.hasPrefix("```"), let firstNewline = candidate.firstIndex(of: "\n"), let endFence = candidate.range(of: "```", options: .backwards) {
            candidate = String(candidate[candidate.index(after: firstNewline)..<endFence.lowerBound]).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        guard let start = candidate.firstIndex(of: "{") else { return nil }
        let payload = String(candidate[start...])
        let base: String
        if let end = payload.lastIndex(of: "}") {
            base = String(payload[...end])
        } else {
            base = payload
        }

        for missingBraces in 0...2 {
            let repaired = base + String(repeating: "}", count: missingBraces)
            guard let data = repaired.data(using: .utf8),
                  let root = try? JSONDecoder().decode(JSONValue.self, from: data),
                  case .object(let object) = root else { continue }
            let action = object["action"]?.stringValue
            let name = object["tool_call"]?.stringValue ?? (action == "tool_call" ? object["tool"]?.stringValue : nil)
            guard let name else { continue }
            let arguments: [String: JSONValue]
            if case .object(let values) = object["arguments"] { arguments = values }
            else { arguments = [:] }
            return ToolCallRequest(name: name, arguments: arguments)
        }
        return nil
    }
}

private extension JSONEncoder {
    static var sorted: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return encoder
    }
}

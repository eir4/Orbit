import Foundation

public struct ASCIICanvasTool: OrbitTool {
    private static let maxRows = 80
    private static let maxColumns = 256

    public init() {}

    public var descriptor: OrbitToolDescriptor {
        OrbitToolDescriptor(
            name: "ascii_canvas",
            description: "Render a monospaced text image from literal rows. Supply `rows` as an array of 1–80 lines, each up to 256 characters; printable ASCII and Unicode box/block symbols are allowed. Do not send a request prompt.",
            inputSchema: #"{"type":"object","properties":{"rows":{"type":"array","items":{"type":"string","maxLength":256},"minItems":1,"maxItems":80}},"required":["rows"]}"#
        )
    }

    public func execute(arguments: [String: JSONValue]) throws -> String {
        let rows: [String]
        if let value = arguments["rows"], case .array(let values) = value {
            rows = values.compactMap(\.stringValue)
            guard rows.count == values.count else { throw OrbitToolError.invalidCanvas }
        } else if let text = arguments["rows"]?.stringValue {
            rows = text.components(separatedBy: .newlines)
        } else if arguments["input"] != nil {
            throw OrbitToolError.invalidArgument("rows must be an array of literal text rows; do not use input")
        } else {
            throw OrbitToolError.missingArgument("rows")
        }

        let forbidden = CharacterSet.controlCharacters.union(.newlines)
        guard !rows.isEmpty, rows.count <= Self.maxRows,
              rows.allSatisfy({ row in
                  row.count <= Self.maxColumns && row.unicodeScalars.allSatisfy { !forbidden.contains($0) }
              }) else {
            throw OrbitToolError.invalidCanvas
        }

        let width = rows.map(\.count).max() ?? 0
        return "ASCII canvas · \(width) × \(rows.count)\n" + rows.joined(separator: "\n")
    }
}

import Foundation

public struct OrbitPoint2D: Equatable, Sendable {
    public let x: Double
    public let y: Double

    public init(x: Double, y: Double) {
        self.x = x
        self.y = y
    }
}

public enum TempleOSBSpline {
    /// Samples a uniform cubic B-spline. Each segment uses four consecutive control points.
    public static func curve(controlPoints: [OrbitPoint2D], samplesPerSegment: Int = 24) -> [OrbitPoint2D] {
        guard controlPoints.count >= 4 else { return [] }
        let samples = max(1, samplesPerSegment)
        var result: [OrbitPoint2D] = []
        for segment in 0..<(controlPoints.count - 3) {
            for sample in 0...samples {
                if segment > 0 && sample == 0 { continue }
                let t = Double(sample) / Double(samples)
                let t2 = t * t
                let t3 = t2 * t
                let oneMinusT = 1 - t
                let weights = [
                    oneMinusT * oneMinusT * oneMinusT / 6,
                    (3 * t3 - 6 * t2 + 4) / 6,
                    (-3 * t3 + 3 * t2 + 3 * t + 1) / 6,
                    t3 / 6
                ]
                let points = controlPoints[segment...(segment + 3)]
                let x = zip(points, weights).reduce(0.0) { $0 + $1.0.x * $1.1 }
                let y = zip(points, weights).reduce(0.0) { $0 + $1.0.y * $1.1 }
                result.append(OrbitPoint2D(x: x, y: y))
            }
        }
        return result
    }
}

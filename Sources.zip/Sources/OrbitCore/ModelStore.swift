import Foundation

public struct LocalModelDescriptor: Equatable, Identifiable, Sendable {
    public let id: String
    public let name: String
    public let directory: URL
    public let modelType: String
    public let architecture: String
    public let supportsVision: Bool
    public let weightByteCount: UInt64

    public init(
        id: String,
        name: String,
        directory: URL,
        modelType: String,
        architecture: String,
        supportsVision: Bool = false,
        weightByteCount: UInt64 = 0
    ) {
        self.id = id
        self.name = name
        self.directory = directory
        self.modelType = modelType
        self.architecture = architecture
        self.supportsVision = supportsVision
        self.weightByteCount = weightByteCount
    }
}

public struct ModelWeightPartition: Equatable, Sendable {
    public let loadable: [LocalModelDescriptor]
    public let overBudget: [LocalModelDescriptor]
}

/// Discovers locally stored generative MLX model bundles without opening their weight files.
public enum ModelStore {
    public static func defaultRoot(environment: [String: String] = ProcessInfo.processInfo.environment, home: URL = FileManager.default.homeDirectoryForCurrentUser) -> URL {
        if let override = environment["OSU_MODELS_DIR"], !override.isEmpty {
            return URL(fileURLWithPath: override, isDirectory: true)
        }
        return home.appendingPathComponent("MLXModels", isDirectory: true)
    }

    /// Searches Osaurus's library, Orbit's LocalAI folder, and an optional extra root.
    /// Keep MLXModels first so its existing model IDs remain stable.
    public static func defaultRoots(environment: [String: String] = ProcessInfo.processInfo.environment, home: URL = FileManager.default.homeDirectoryForCurrentUser) -> [URL] {
        var candidates = [
            home.appendingPathComponent("MLXModels", isDirectory: true),
            home.appendingPathComponent("LocalAI", isDirectory: true)
        ]
        if let override = environment["OSU_MODELS_DIR"], !override.isEmpty {
            candidates.append(URL(fileURLWithPath: override, isDirectory: true))
        }
        var seen = Set<String>()
        return candidates.filter { seen.insert($0.standardizedFileURL.path).inserted }
    }

    public static func partitionByWeightBudget(_ models: [LocalModelDescriptor], maximumWeightBytes: UInt64) -> ModelWeightPartition {
        ModelWeightPartition(
            loadable: models.filter { $0.weightByteCount <= maximumWeightBytes },
            overBudget: models.filter { $0.weightByteCount > maximumWeightBytes }
        )
    }

    public static func discover(in roots: [URL], fileManager: FileManager = .default, maxDepth: Int = 6) -> [LocalModelDescriptor] {
        let uniqueRoots = roots.reduce(into: [URL]()) { result, root in
            if !result.contains(where: { $0.standardizedFileURL.path == root.standardizedFileURL.path }) {
                result.append(root)
            }
        }
        var found: [LocalModelDescriptor] = []
        for (index, root) in uniqueRoots.enumerated() {
            let rootModels = discover(at: root, fileManager: fileManager, maxDepth: maxDepth)
            found.append(contentsOf: rootModels.map { model in
                guard index > 0 else { return model }
                return LocalModelDescriptor(
                    id: "\(root.lastPathComponent)/\(model.id)",
                    name: model.name,
                    directory: model.directory,
                    modelType: model.modelType,
                    architecture: model.architecture,
                    supportsVision: model.supportsVision,
                    weightByteCount: model.weightByteCount
                )
            })
        }
        return found.sorted { $0.id.localizedStandardCompare($1.id) == .orderedAscending }
    }

    public static func discover(at root: URL, fileManager: FileManager = .default, maxDepth: Int = 6) -> [LocalModelDescriptor] {
        guard let rootValues = try? root.resourceValues(forKeys: [.isDirectoryKey]), rootValues.isDirectory == true else { return [] }
        var found: [LocalModelDescriptor] = []

        func visit(_ directory: URL, depth: Int) {
            guard depth <= maxDepth else { return }
            let configURL = directory.appendingPathComponent("config.json")
            if let descriptor = descriptor(at: directory, configURL: configURL, root: root, fileManager: fileManager) {
                found.append(descriptor)
                return
            }
            guard let children = try? fileManager.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.isDirectoryKey],
                options: [.skipsHiddenFiles, .skipsPackageDescendants]
            ) else { return }
            for child in children.sorted(by: { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }) {
                guard let values = try? child.resourceValues(forKeys: [.isDirectoryKey]), values.isDirectory == true else { continue }
                visit(child, depth: depth + 1)
            }
        }

        visit(root, depth: 0)
        return found.sorted { $0.id.localizedStandardCompare($1.id) == .orderedAscending }
    }

    private static func descriptor(at directory: URL, configURL: URL, root: URL, fileManager: FileManager) -> LocalModelDescriptor? {
        guard let configData = try? Data(contentsOf: configURL),
              let object = try? JSONSerialization.jsonObject(with: configData) as? [String: Any] else { return nil }
        let modelType = (object["model_type"] as? String) ?? ""
        let architectures = object["architectures"] as? [String] ?? []
        let architecture = architectures.first ?? ""
        let normalized = architecture.lowercased()
        let isGenerative = normalized.contains("forcausallm") || normalized.contains("forconditionalgeneration")
        guard isGenerative else { return nil }

        let children = (try? fileManager.contentsOfDirectory(atPath: directory.path)) ?? []
        let weightFiles = children.filter { $0.hasSuffix(".safetensors") || $0.hasSuffix(".npz") }
        let hasTokenizer = ["tokenizer.json", "tokenizer_config.json", "tokenizer.model", "vocab.json"].contains { children.contains($0) }
        guard !weightFiles.isEmpty, hasTokenizer else { return nil }

        let weightByteCount = weightFiles.reduce(into: UInt64(0)) { total, name in
            let attributes = try? fileManager.attributesOfItem(atPath: directory.appendingPathComponent(name).path)
            total &+= (attributes?[.size] as? NSNumber)?.uint64Value ?? 0
        }
        let rootParts = root.standardizedFileURL.resolvingSymlinksInPath().pathComponents
        let directoryParts = directory.standardizedFileURL.resolvingSymlinksInPath().pathComponents
        let relative = directoryParts.starts(with: rootParts)
            ? directoryParts.dropFirst(rootParts.count).joined(separator: "/")
            : directory.lastPathComponent
        let vision = normalized.contains("vision") || normalized.contains("conditionalgeneration")
        return LocalModelDescriptor(
            id: relative,
            name: directory.lastPathComponent,
            directory: directory,
            modelType: modelType,
            architecture: architecture,
            supportsVision: vision,
            weightByteCount: weightByteCount
        )
    }
}

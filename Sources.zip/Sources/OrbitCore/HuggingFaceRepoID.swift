import Foundation

public struct HuggingFaceRepoID: Equatable, Hashable, Sendable {
    public let value: String

    public init(_ rawValue: String) throws {
        let raw = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let candidate: String
        if raw.hasPrefix("https://") {
            guard let components = URLComponents(string: raw),
                  components.host?.lowercased() == "huggingface.co",
                  components.query == nil,
                  components.fragment == nil else {
                throw HuggingFaceRepoIDError.invalidIdentifier
            }
            candidate = components.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        } else {
            candidate = raw
        }

        let parts = candidate.split(separator: "/", omittingEmptySubsequences: false).map(String.init)
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-")
        guard parts.count == 2,
              parts.allSatisfy({ !$0.isEmpty && $0 != "." && $0 != ".." && $0.unicodeScalars.allSatisfy(allowed.contains) }) else {
            throw HuggingFaceRepoIDError.invalidIdentifier
        }
        value = parts.joined(separator: "/")
    }
}

public enum HuggingFaceRepoIDError: LocalizedError {
    case invalidIdentifier

    public var errorDescription: String? {
        "Enter a Hugging Face model ID as owner/repository, or paste a huggingface.co model URL."
    }
}

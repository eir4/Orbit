import Foundation

public enum ConversationArchiveCodec {
    private static let header = "Orbit conversation archive v1"

    public static func encode(_ conversation: ConversationRecord) throws -> String {
        var lines = [
            header,
            "Title: \(try encodeJSONString(conversation.title))",
            "Conversation ID: \(conversation.id.uuidString)",
            "Updated: \(encodeDate(conversation.updatedAt))",
            ""
        ]
        for entry in conversation.entries {
            let role: String
            switch entry.kind {
            case .user: role = "User message"
            case .activity: role = "LLM thinking"
            case .assistant: role = "LLM response"
            case .specialist: role = "Specialist response"
            }
            let modelID = try entry.modelID.map(encodeJSONString) ?? "null"
            lines.append("\(role): \(try encodeJSONString(entry.text))")
            lines.append("Timestamp: \(encodeDate(entry.createdAt))")
            lines.append("Model ID: \(modelID)")
            lines.append("")
        }
        return lines.joined(separator: "\n") + "\n"
    }

    public static func decode(_ text: String) throws -> ConversationRecord {
        let lines = text.components(separatedBy: .newlines)
        guard lines.first == header else { throw ConversationArchiveError.invalidHeader }
        let headerLines = Array(lines.dropFirst().prefix { !$0.isEmpty })
        let fields = Dictionary(headerLines.compactMap { line -> (String, String)? in
            guard let separator = line.range(of: ": ") else { return nil }
            return (String(line[..<separator.lowerBound]), String(line[separator.upperBound...]))
        }, uniquingKeysWith: { first, _ in first })
        guard let titleValue = fields["Title"],
              let conversationID = fields["Conversation ID"].flatMap(UUID.init(uuidString:)),
              let updatedValue = fields["Updated"] else {
            throw ConversationArchiveError.missingHeaderField
        }

        var entries: [ConversationEntry] = []
        var index = 1 + headerLines.count
        while index < lines.count {
            if lines[index].isEmpty {
                index += 1
                continue
            }
            let messageLine = lines[index]
            guard let separator = messageLine.range(of: ": ") else {
                throw ConversationArchiveError.invalidMessageLine(messageLine)
            }
            let role = String(messageLine[..<separator.lowerBound])
            let messageText = try decodeJSONString(String(messageLine[separator.upperBound...]))
            guard index + 2 < lines.count,
                  lines[index + 1].hasPrefix("Timestamp: "),
                  lines[index + 2].hasPrefix("Model ID: ") else {
                throw ConversationArchiveError.invalidMessageLine(messageLine)
            }
            let createdAt = try decodeDate(String(lines[index + 1].dropFirst("Timestamp: ".count)))
            let encodedModelID = String(lines[index + 2].dropFirst("Model ID: ".count))
            let modelID = encodedModelID == "null" ? nil : try decodeJSONString(encodedModelID)
            let kind: ConversationEntryKind
            switch role {
            case "User message": kind = .user
            case "LLM thinking": kind = .activity
            case "LLM response": kind = .assistant
            case "Specialist response": kind = .specialist
            default: throw ConversationArchiveError.unknownRole(role)
            }
            entries.append(ConversationEntry(kind: kind, text: messageText, modelID: modelID, createdAt: createdAt))
            index += 3
        }

        return ConversationRecord(
            id: conversationID,
            title: try decodeJSONString(titleValue),
            updatedAt: try decodeDate(updatedValue),
            entries: entries
        )
    }

    private static func encodeJSONString(_ value: String) throws -> String {
        let data = try JSONEncoder().encode(value)
        guard let result = String(data: data, encoding: .utf8) else { throw ConversationArchiveError.invalidStringEncoding }
        return result
    }

    private static func decodeJSONString(_ value: String) throws -> String {
        guard let data = value.data(using: .utf8) else { throw ConversationArchiveError.invalidStringEncoding }
        return try JSONDecoder().decode(String.self, from: data)
    }

    private static func encodeDate(_ value: Date) -> String {
        ISO8601DateFormatter().string(from: value)
    }

    private static func decodeDate(_ value: String) throws -> Date {
        guard let date = ISO8601DateFormatter().date(from: value) else { throw ConversationArchiveError.invalidDate(value) }
        return date
    }
}

public enum ConversationArchiveError: LocalizedError {
    case invalidHeader
    case missingHeaderField
    case invalidMessageLine(String)
    case unknownRole(String)
    case invalidDate(String)
    case invalidStringEncoding

    public var errorDescription: String? {
        switch self {
        case .invalidHeader: "This file is not an Orbit conversation archive v1."
        case .missingHeaderField: "The Orbit archive is missing its title, conversation ID, or update date."
        case .invalidMessageLine(let line): "Could not read an archived message line: \(line)"
        case .unknownRole(let role): "Unknown conversation archive message type: \(role)"
        case .invalidDate(let date): "Invalid date in conversation archive: \(date)"
        case .invalidStringEncoding: "Could not encode or decode an archived string."
        }
    }
}

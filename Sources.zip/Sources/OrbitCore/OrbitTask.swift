import Foundation

public enum OrbitTaskStatus: String, Codable, Sendable {
    case pending
    case inProgress
    case completed
}

public struct OrbitTask: Codable, Equatable, Identifiable, Sendable {
    public var id: UUID
    public var title: String
    public var modelID: String?
    public var status: OrbitTaskStatus
    public var createdAt: Date
    public var startedAt: Date?
    public var completedAt: Date?

    public init(
        id: UUID = UUID(),
        title: String,
        modelID: String? = nil,
        status: OrbitTaskStatus = .pending,
        createdAt: Date = .now,
        startedAt: Date? = nil,
        completedAt: Date? = nil
    ) {
        self.id = id
        self.title = title
        self.modelID = modelID
        self.status = status
        self.createdAt = createdAt
        self.startedAt = startedAt
        self.completedAt = completedAt
    }

    public func progressEstimate(at now: Date = .now) -> Int {
        switch status {
        case .pending: return 0
        case .completed: return 100
        case .inProgress:
            let elapsed = max(0, now.timeIntervalSince(startedAt ?? createdAt))
            return min(90, 10 + Int((elapsed / 60) * 80))
        }
    }
}

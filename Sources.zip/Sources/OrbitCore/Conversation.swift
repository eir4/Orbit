import Foundation

public enum ConversationEntryKind: String, Codable, Sendable {
    case user
    case assistant
    case specialist
    case activity
}

public struct ConversationEntry: Identifiable, Codable, Sendable {
    public var id: UUID
    public var kind: ConversationEntryKind
    public var text: String
    public var modelID: String?
    public var createdAt: Date

    public init(id: UUID = UUID(), kind: ConversationEntryKind, text: String, modelID: String? = nil, createdAt: Date = .now) {
        self.id = id
        self.kind = kind
        self.text = text
        self.modelID = modelID
        self.createdAt = createdAt
    }
}

public struct ConversationRecord: Identifiable, Codable, Sendable {
    public var id: UUID
    public var title: String
    public var updatedAt: Date
    public var entries: [ConversationEntry]
    public var isPinned: Bool
    public var isArchived: Bool

    public init(
        id: UUID = UUID(),
        title: String,
        updatedAt: Date = .now,
        entries: [ConversationEntry] = [],
        isPinned: Bool = false,
        isArchived: Bool = false
    ) {
        self.id = id
        self.title = title
        self.updatedAt = updatedAt
        self.entries = entries
        self.isPinned = isPinned
        self.isArchived = isArchived
    }

    private enum CodingKeys: String, CodingKey {
        case id, title, updatedAt, entries, isPinned, isArchived
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        title = try container.decode(String.self, forKey: .title)
        updatedAt = try container.decode(Date.self, forKey: .updatedAt)
        entries = try container.decode([ConversationEntry].self, forKey: .entries)
        isPinned = try container.decodeIfPresent(Bool.self, forKey: .isPinned) ?? false
        isArchived = try container.decodeIfPresent(Bool.self, forKey: .isArchived) ?? false
    }
}

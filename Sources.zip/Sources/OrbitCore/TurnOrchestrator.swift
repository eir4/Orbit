import Foundation

/// Runs a deliberately serial loop: main model -> one specialist -> main model.
/// Only the specialist receives image payloads; the planner gets compact metadata and results.
public struct TurnOrchestrator: Sendable {
    public let client: any ModelClient
    public let maxWorkerTurns: Int
    public let onEvent: (@Sendable (OrchestrationEvent) async -> Void)?

    public init(client: any ModelClient, maxWorkerTurns: Int = 5, onEvent: (@Sendable (OrchestrationEvent) async -> Void)? = nil) {
        self.client = client
        self.maxWorkerTurns = max(1, maxWorkerTurns)
        self.onEvent = onEvent
    }

    public func run(prompt: String, mainModel: LocalModel, specialistModels: [LocalModel], attachments: [PreparedAttachment] = []) async throws -> String {
        var results: [(task: String, modelID: String, text: String)] = []
        var workerTurns = 0
        var usedEmptyReplyFallback = false

        while true {
            await onEvent?(.mainThinking)
            let currentInput = plannerInput(prompt: prompt, models: specialistModels, attachments: attachments, results: results)
            var plannerReply = try await client.complete(
                modelID: mainModel.id,
                system: Self.plannerSystem,
                user: currentInput,
                images: []
            )

            if plannerReply.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                await onEvent?(.mainThinking)
                plannerReply = try await client.complete(
                    modelID: mainModel.id,
                    system: Self.plannerSystem + "\n\nYour previous response was empty. Return one valid JSON directive now.",
                    user: currentInput,
                    images: []
                )
            }

            if plannerReply.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                if let lastResult = results.last?.text, !lastResult.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    await onEvent?(.mainThinking)
                    let synthesis = try await client.complete(
                        modelID: mainModel.id,
                        system: Self.synthesisFallbackSystem,
                        user: synthesisFallbackInput(prompt: prompt, results: results),
                        images: []
                    )
                    let trimmedSynthesis = synthesis.trimmingCharacters(in: .whitespacesAndNewlines)
                    let final = trimmedSynthesis.isEmpty
                        ? "The coordinator could not synthesize a response, so here is the latest specialist result:\n\n\(lastResult)"
                        : trimmedSynthesis
                    await onEvent?(.completed(final))
                    return final
                }

                if !usedEmptyReplyFallback, workerTurns < maxWorkerTurns, let fallbackModel = specialistModels.first {
                    usedEmptyReplyFallback = true
                    let task = "Give a first-pass response to the user's goal, addressing its main parts concisely."
                    await onEvent?(.delegated(modelID: fallbackModel.id, task: task))
                    let result = try await client.complete(
                        modelID: fallbackModel.id,
                        system: "You are a focused specialist. Do the assigned task directly and return a useful answer. Note uncertainty.",
                        user: specialistInput(prompt: prompt, task: task, attachments: attachments),
                        images: attachments.compactMap(\.imageDataURL)
                    )
                    results.append((task: task, modelID: fallbackModel.id, text: result))
                    workerTurns += 1
                    await onEvent?(.specialistResult(modelID: fallbackModel.id, result: result))
                    continue
                }
                throw OrchestratorError.emptyCoordinatorResponse
            }

            guard let directive = Self.decodeDirective(plannerReply) else {
                await onEvent?(.completed(plannerReply))
                return plannerReply
            }

            switch directive.action.lowercased() {
            case "finish":
                let answer = directive.answer?.trimmingCharacters(in: .whitespacesAndNewlines)
                let final = answer?.isEmpty == false ? answer! : "I couldn't produce a final answer."
                await onEvent?(.completed(final))
                return final

            case "delegate":
                guard workerTurns < maxWorkerTurns else { throw OrchestratorError.workerLimitReached }
                guard let modelID = directive.modelID, let task = directive.task,
                      let model = specialistModels.first(where: { $0.id == modelID }) else {
                    throw OrchestratorError.unknownWorker(directive.modelID ?? "(missing model_id)")
                }
                await onEvent?(.delegated(modelID: model.id, task: task))
                let result = try await client.complete(
                    modelID: model.id,
                    system: "You are a focused specialist. Do only the assigned task. Base claims on the supplied files; name the file and relevant page, line, cell, or byte offset when possible. Return a concise result and note uncertainty.",
                    user: specialistInput(prompt: prompt, task: task, attachments: attachments),
                    images: attachments.compactMap(\.imageDataURL)
                )
                results.append((task: task, modelID: model.id, text: result))
                workerTurns += 1
                await onEvent?(.specialistResult(modelID: model.id, result: result))
                // Loop back through the main model before another worker can run.

            default:
                throw OrchestratorError.malformedDirective
            }
        }
    }

    private static let plannerSystem = """
    You are the lightweight coordinator for a local-model squad. Organize work; do not do specialist analysis yourself. Choose exactly one action as JSON, with no markdown:
    {"action":"delegate","model_id":"an available model id","task":"one focused instruction"}
    or {"action":"finish","answer":"the synthesized response"}
    After every specialist result, inspect it before choosing the next specialist or finishing. If the goal has multiple distinct parts or substantial work, delegate at least one focused step rather than doing the analysis in the coordinator. Delegate only to an ID in the supplied specialist list. Keep the number of steps small. Preserve uncertainty and cite attachment names and locations in the final answer.
    """

    private static let synthesisFallbackSystem = """
    You are the coordinator for a local-model squad. The structured planning response failed, but the specialist work is available. Answer the user's goal directly using the supplied specialist results. Be concise, preserve uncertainty, and do not return an empty answer.
    """

    private func synthesisFallbackInput(prompt: String, results: [(task: String, modelID: String, text: String)]) -> String {
        let resultList = results.enumerated().map { index, item in
            "\(index + 1). \(item.modelID) — \(item.task)\n\(item.text)"
        }.joined(separator: "\n\n")
        return """
        USER GOAL:
        \(prompt)

        SPECIALIST RESULTS:
        \(resultList)

        Synthesize these results into a direct response to the goal.
        """
    }

    private func plannerInput(prompt: String, models: [LocalModel], attachments: [PreparedAttachment], results: [(task: String, modelID: String, text: String)]) -> String {
        let modelList = models.map { "- \($0.id) — \($0.role)" }.joined(separator: "\n")
        let fileList = attachments.map { "- \($0.name) [\($0.kind.rawValue), \($0.byteCount) bytes]: \($0.summary)" }.joined(separator: "\n")
        let resultList = results.enumerated().map { index, item in
            "\(index + 1). \(item.modelID), task: \(item.task)\nResult: \(item.text)"
        }.joined(separator: "\n\n")
        return """
        USER GOAL:
        \(prompt)

        AVAILABLE SPECIALISTS:
        \(modelList.isEmpty ? "(none; answer directly)" : modelList)

        ATTACHMENTS:
        \(fileList.isEmpty ? "(none)" : fileList)

        RESULTS SO FAR:
        \(resultList.isEmpty ? "(none; decide the first useful task)" : resultList)
        """
    }

    private func specialistInput(prompt: String, task: String, attachments: [PreparedAttachment]) -> String {
        let fileContext = attachments.map { attachment in
            let body = attachment.text.isEmpty ? attachment.summary : attachment.text
            return "FILE: \(attachment.name) [\(attachment.kind.rawValue)]\n\(body)"
        }.joined(separator: "\n\n")
        return """
        Original goal: \(prompt)
        Your task: \(task)

        ATTACHED FILE CONTEXT:
        \(fileContext.isEmpty ? "(no extracted text; inspect attached image payloads if present)" : fileContext)
        """
    }

    private static func decodeDirective(_ text: String) -> Directive? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let candidates = [trimmed, String(trimmed.drop(while: { $0 != "{" }).reversed().drop(while: { $0 != "}" }).reversed())]
        for candidate in candidates {
            guard let data = candidate.data(using: .utf8),
                  let directive = try? JSONDecoder().decode(Directive.self, from: data) else { continue }
            return directive
        }
        return nil
    }

    private struct Directive: Decodable {
        let action: String
        let modelID: String?
        let task: String?
        let answer: String?

        enum CodingKeys: String, CodingKey {
            case action
            case modelID = "model_id"
            case task
            case answer
        }
    }
}

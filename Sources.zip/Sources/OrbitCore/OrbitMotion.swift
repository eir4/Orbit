import Foundation

public struct OrbitPosition: Equatable, Sendable {
    public let x: Double
    public let y: Double

    public init(x: Double, y: Double) {
        self.x = x
        self.y = y
    }
}

/// Deterministic slow orbit with small radial and tangential oscillations.
public enum OrbitMotion {
    private static let orbitPeriod = 120.0

    public static func position(index: Int, count: Int, time: Double, radius: Double) -> OrbitPosition {
        let safeCount = max(1, count)
        let safeIndex = ((index % safeCount) + safeCount) % safeCount
        let phase = (Double(safeIndex) + 0.5) * 2 * Double.pi / Double(safeCount)
        let cycleTime = time.truncatingRemainder(dividingBy: orbitPeriod)
        let rotation = 2 * Double.pi * cycleTime / orbitPeriod
        let angularWobble = sin(2 * Double.pi * cycleTime / 12 + phase) * 0.025
            + sin(2 * Double.pi * cycleTime / 8 + phase * 1.3) * 0.009
        let radialWobble = sin(2 * Double.pi * cycleTime / 20 + phase) * 3
            + sin(2 * Double.pi * cycleTime / 15 + phase * 0.7) * 1.2
        let distance = max(0, radius + radialWobble)
        let angle = phase + rotation + angularWobble
        return OrbitPosition(x: cos(angle) * distance, y: sin(angle) * distance)
    }

    public static func wavePosition(index: Int, count: Int, time: Double, spacing: Double, amplitude: Double) -> OrbitPosition {
        let safeCount = max(1, count)
        let safeIndex = ((index % safeCount) + safeCount) % safeCount
        let x = (Double(safeIndex) - Double(safeCount - 1) / 2) * spacing
        let cycleTime = time.truncatingRemainder(dividingBy: 12)
        let phase = 2 * Double.pi * cycleTime / 5.2 - Double(safeIndex) * 0.72
        let y = sin(phase) * amplitude + sin(phase * 0.58 + Double(safeIndex) * 0.33) * amplitude * 0.16
        return OrbitPosition(x: x, y: y)
    }

    /// One coordinator pulse moves from orb to orb; each pulse fades in and out smoothly.
    public static func coordinatorPulse(index: Int, count: Int, time: Double, stepDuration: Double = 1.4) -> Double {
        let safeCount = max(1, count)
        let safeIndex = ((index % safeCount) + safeCount) % safeCount
        let cycleDuration = stepDuration * Double(safeCount)
        let cycleTime = time.truncatingRemainder(dividingBy: cycleDuration)
        let activeIndex = min(safeCount - 1, Int(cycleTime / stepDuration))
        guard safeIndex == activeIndex else { return 0.04 }
        let localPhase = (cycleTime - Double(activeIndex) * stepDuration) / stepDuration
        let breath = 0.5 - 0.5 * cos(2 * Double.pi * localPhase)
        return 0.12 + 0.88 * breath
    }

    public static func breathingPulse(time: Double, phase: Double = 0, cycleDuration: Double = 1.8) -> Double {
        let cycleTime = time.truncatingRemainder(dividingBy: cycleDuration)
        let breath = 0.5 - 0.5 * cos(2 * Double.pi * cycleTime / cycleDuration + phase)
        return 0.2 + 0.8 * breath
    }
}

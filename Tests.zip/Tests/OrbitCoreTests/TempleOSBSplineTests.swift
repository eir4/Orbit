import XCTest
@testable import OrbitCore

final class TempleOSBSplineTests: XCTestCase {
    func testCubicBSplineUsesFourControlPointsAndSamplesSegment() {
        let control = [
            OrbitPoint2D(x: 0, y: 0),
            OrbitPoint2D(x: 1, y: 0),
            OrbitPoint2D(x: 2, y: 0),
            OrbitPoint2D(x: 3, y: 0)
        ]

        let curve = TempleOSBSpline.curve(controlPoints: control, samplesPerSegment: 20)

        XCTAssertEqual(curve.count, 21)
        XCTAssertEqual(curve.first?.x ?? .nan, 1, accuracy: 0.0001)
        XCTAssertEqual(curve.last?.x ?? .nan, 2, accuracy: 0.0001)
        XCTAssertTrue(curve.allSatisfy { $0.y == 0 })
    }

    func testBSplineNeedsAtLeastFourControlPoints() {
        XCTAssertTrue(TempleOSBSpline.curve(controlPoints: [
            OrbitPoint2D(x: 0, y: 0),
            OrbitPoint2D(x: 1, y: 1),
            OrbitPoint2D(x: 2, y: 0)
        ]).isEmpty)
    }
}

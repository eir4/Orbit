import XCTest
@testable import OrbitCore

final class TempleOSToolsTests: XCTestCase {
    func testMusicNotesProducesASeededMelodyWithRequestedLength() throws {
        let arguments: [String: JSONValue] = [
            "root": .string("C"),
            "scale": .string("major"),
            "count": .number(8),
            "tempo": .number(96),
            "seed": .number(42)
        ]

        let first = try TempleOSMusicNotesTool().execute(arguments: arguments)
        let second = try TempleOSMusicNotesTool().execute(arguments: arguments)
        let notes = first.components(separatedBy: "\n").last?.split(whereSeparator: \.isWhitespace) ?? []

        XCTAssertEqual(first, second)
        XCTAssertTrue(first.contains("tempo=96"))
        XCTAssertTrue(first.contains("seed=42"))
        XCTAssertEqual(notes.count, 8)
        XCTAssertEqual(notes.first, "C4")
    }

    func testMusicNotesRejectsOutOfRangeLengthAndUnknownScale() {
        XCTAssertThrowsError(try TempleOSMusicNotesTool().execute(arguments: ["count": .number(17)]))
        XCTAssertThrowsError(try TempleOSMusicNotesTool().execute(arguments: ["scale": .string("mystery")]))
    }

    func testGodWordGeneratorIsSeededAndHonorsCount() throws {
        let arguments: [String: JSONValue] = ["count": .number(3), "seed": .number(42)]
        let first = try TempleOSGodWordTool().execute(arguments: arguments)
        let second = try TempleOSGodWordTool().execute(arguments: arguments)
        let words = first.components(separatedBy: ": ").last?.components(separatedBy: ", ") ?? []

        XCTAssertEqual(first, second)
        XCTAssertEqual(words.count, 3)
        XCTAssertTrue(first.contains("seed=42"))
    }

    func testMusicNotesIsRegisteredButGodWordIsNotModelCallable() throws {
        let names = ToolRegistry.builtIn.descriptors.map(\.name)
        XCTAssertTrue(names.contains("templeos_music_notes"))
        XCTAssertFalse(names.contains("templeos_god_word"))
        XCTAssertThrowsError(try ToolRegistry.builtIn.execute(name: "templeos_god_word", arguments: [:]))
    }
}

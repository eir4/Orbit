import XCTest
@testable import OrbitCore

final class AttachmentKindTests: XCTestCase {
    func testHexPreviewKeepsOffsetsBytesAndReadableColumns() {
        let output = HexFormatter.preview(Data([0x41, 0x00, 0x42]), maxBytes: 3, bytesPerRow: 3)
        XCTAssertTrue(output.contains("00000000"))
        XCTAssertTrue(output.contains("41 00 42"))
        XCTAssertTrue(output.contains("|A.B|"))
    }

    func testRoutesCommonFilesWithoutGuessingFromTheirContents() {
        XCTAssertEqual(AttachmentKind.infer(fileExtension: "PDF"), .pdf)
        XCTAssertEqual(AttachmentKind.infer(fileExtension: "swift"), .text)
        XCTAssertEqual(AttachmentKind.infer(fileExtension: "png"), .image)
        XCTAssertEqual(AttachmentKind.infer(fileExtension: "hex"), .hex)
        XCTAssertEqual(AttachmentKind.infer(fileExtension: "unknown"), .other)
    }
}

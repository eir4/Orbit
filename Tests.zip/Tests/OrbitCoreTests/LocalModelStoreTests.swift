import XCTest
@testable import OrbitCore

final class LocalModelStoreTests: XCTestCase {
    func testDiscoversRunnableGenerativeBundlesAndSkipsImagePipelineParts() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        defer { try? FileManager.default.removeItem(at: root) }

        try makeBundle(root.appendingPathComponent("OsaurusAI/Raptor-4B"), modelType: "spark2_5", architecture: "Spark2_5ForCausalLM")
        try makeBundle(root.appendingPathComponent("image/Flux/transformer"), modelType: "flux", architecture: "FluxTransformer2DModel")
        try makeBundle(root.appendingPathComponent("image/Flux/text_encoder"), modelType: "qwen3_vl_text", architecture: "Qwen3VLTextModel")

        let found = ModelStore.discover(at: root)
        XCTAssertEqual(found.map(\.name), ["Raptor-4B"])
        XCTAssertEqual(found.first?.modelType, "spark2_5")
        XCTAssertEqual(found.first?.weightByteCount, 1)
    }

    func testDiscoversBundlesFromMultipleRootsAndPrefixesSecondaryRoots() throws {
        let temp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        defer { try? FileManager.default.removeItem(at: temp) }
        let mlxRoot = temp.appendingPathComponent("MLXModels", isDirectory: true)
        let localRoot = temp.appendingPathComponent("LocalAI", isDirectory: true)
        try makeBundle(mlxRoot.appendingPathComponent("OsaurusAI/Raptor-4B"), modelType: "spark2_5", architecture: "Spark2_5ForCausalLM")
        let medgemma = localRoot.appendingPathComponent("medgemma-1.5-4b-it")
        try makeBundle(medgemma, modelType: "gemma3", architecture: "Gemma3ForConditionalGeneration")
        try Data(repeating: 0x01, count: 4).write(to: medgemma.appendingPathComponent("model-00002-of-00002.safetensors"))

        let found = ModelStore.discover(in: [mlxRoot, localRoot])
        XCTAssertEqual(found.map(\.id), ["LocalAI/medgemma-1.5-4b-it", "OsaurusAI/Raptor-4B"])
        XCTAssertEqual(found.first(where: { $0.name == "medgemma-1.5-4b-it" })?.weightByteCount, 5)
    }

    func testDefaultRootsIncludeOsaurusAndLocalAIFoldersAndAnOptionalExtraRoot() {
        let home = URL(fileURLWithPath: "/mock/home", isDirectory: true)
        let roots = ModelStore.defaultRoots(environment: ["OSU_MODELS_DIR": "/models/extra"], home: home)
        XCTAssertEqual(roots, [
            home.appendingPathComponent("MLXModels", isDirectory: true),
            home.appendingPathComponent("LocalAI", isDirectory: true),
            URL(fileURLWithPath: "/models/extra", isDirectory: true)
        ])
    }

    func testPartitionsBundlesAgainstSafeWeightBudget() {
        let directory = URL(fileURLWithPath: "/models", isDirectory: true)
        let small = LocalModelDescriptor(id: "small", name: "small", directory: directory, modelType: "llama", architecture: "LlamaForCausalLM", weightByteCount: 100)
        let large = LocalModelDescriptor(id: "large", name: "large", directory: directory, modelType: "gemma3", architecture: "Gemma3ForConditionalGeneration", weightByteCount: 200)

        let result = ModelStore.partitionByWeightBudget([small, large], maximumWeightBytes: 150)
        XCTAssertEqual(result.loadable.map(\.id), ["small"])
        XCTAssertEqual(result.overBudget.map(\.id), ["large"])
    }

    private func makeBundle(_ directory: URL, modelType: String, architecture: String) throws {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let config = "{\"model_type\":\"\(modelType)\",\"architectures\":[\"\(architecture)\"]}"
        try Data(config.utf8).write(to: directory.appendingPathComponent("config.json"))
        try Data("{}".utf8).write(to: directory.appendingPathComponent("tokenizer_config.json"))
        try Data([0x00]).write(to: directory.appendingPathComponent("model.safetensors"))
    }
}

import XCTest
@testable import OrbitCore

final class QuickTextCalculatorRouterTests: XCTestCase {
    func testQuickTextRoutesBareArithmeticToBasicCalculator() throws {
        let model = LocalModel(id: "local-quick", role: "Quick text")

        let answer = try QuickTextCalculatorRouter.answer(model: model, prompt: "5+2")

        XCTAssertEqual(answer, "7")
    }

    func testOtherModelRolesDoNotTakeTheShortcut() throws {
        let model = LocalModel(id: "local-reasoning", role: "Reasoning")

        XCTAssertNil(try QuickTextCalculatorRouter.answer(model: model, prompt: "5+2"))
    }

    func testNaturalLanguageAndSmileysDoNotRouteToCalculator() throws {
        let model = LocalModel(id: "local-quick", role: "Quick text")

        XCTAssertNil(try QuickTextCalculatorRouter.answer(model: model, prompt: "What is 5+2?"))
        XCTAssertNil(try QuickTextCalculatorRouter.answer(model: model, prompt: ":)"))
        XCTAssertNil(try QuickTextCalculatorRouter.answer(model: model, prompt: "(^_^)"))
    }

    func testRoutesArithmeticErrorsThroughTheCalculator() {
        let model = LocalModel(id: "local-quick", role: "Quick text")

        XCTAssertThrowsError(try QuickTextCalculatorRouter.answer(model: model, prompt: "5/0"))
    }
}

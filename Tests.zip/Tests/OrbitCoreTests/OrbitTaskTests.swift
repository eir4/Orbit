import XCTest
@testable import OrbitCore

final class OrbitTaskTests: XCTestCase {
    func testProgressEstimateReflectsStatusAndTime() {
        let start = Date(timeIntervalSince1970: 1_700_000_000)
        let pending = OrbitTask(title: "Read file", status: .pending, createdAt: start)
        let running = OrbitTask(title: "Analyze file", status: .inProgress, createdAt: start, startedAt: start)
        let completed = OrbitTask(title: "Write answer", status: .completed, createdAt: start, completedAt: start)

        XCTAssertEqual(pending.progressEstimate(at: start), 0)
        XCTAssertEqual(running.progressEstimate(at: start), 10)
        XCTAssertEqual(running.progressEstimate(at: start.addingTimeInterval(30)), 50)
        XCTAssertEqual(running.progressEstimate(at: start.addingTimeInterval(120)), 90)
        XCTAssertEqual(completed.progressEstimate(at: start), 100)
    }
}

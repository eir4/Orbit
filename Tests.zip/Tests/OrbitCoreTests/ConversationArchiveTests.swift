import XCTest
@testable import OrbitCore

final class ConversationArchiveTests: XCTestCase {
    func testTextArchiveRoundTripsKindsOrderTimestampsAndSpecialistModel() throws {
        let id = UUID()
        let date = Date(timeIntervalSince1970: 1_710_000_000)
        let entries = [
            ConversationEntry(kind: .user, text: "First line\n\"quoted\"", createdAt: date),
            ConversationEntry(kind: .activity, text: "Coordinator reviewing", createdAt: date.addingTimeInterval(1)),
            ConversationEntry(kind: .specialist, text: "2", modelID: "LocalAI/model-A", createdAt: date.addingTimeInterval(2)),
            ConversationEntry(kind: .assistant, text: "The result is 2.", createdAt: date.addingTimeInterval(3))
        ]
        let record = ConversationRecord(id: id, title: "Math \"test\"", updatedAt: date.addingTimeInterval(3), entries: entries, isPinned: true, isArchived: true)

        let text = try ConversationArchiveCodec.encode(record)
        XCTAssertTrue(text.contains("User message:"))
        XCTAssertTrue(text.contains("LLM thinking:"))
        XCTAssertTrue(text.contains("LLM response:"))

        let restored = try ConversationArchiveCodec.decode(text)
        XCTAssertEqual(restored.id, id)
        XCTAssertEqual(restored.title, record.title)
        XCTAssertEqual(restored.entries.map(\.kind), entries.map(\.kind))
        XCTAssertEqual(restored.entries.map(\.text), entries.map(\.text))
        XCTAssertEqual(restored.entries.map(\.modelID), entries.map(\.modelID))
        XCTAssertEqual(restored.entries.map(\.createdAt), entries.map(\.createdAt))
        XCTAssertFalse(restored.isPinned)
        XCTAssertFalse(restored.isArchived)
    }

    func testLegacyConversationJSONDefaultsPinAndArchiveFlagsToFalse() throws {
        let legacy = """
        {"id":"00000000-0000-0000-0000-000000000001","title":"Legacy","updatedAt":0,"entries":[]}
        """
        let record = try JSONDecoder().decode(ConversationRecord.self, from: Data(legacy.utf8))
        XCTAssertFalse(record.isPinned)
        XCTAssertFalse(record.isArchived)
    }
}

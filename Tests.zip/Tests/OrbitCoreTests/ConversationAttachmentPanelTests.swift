import XCTest
import OrbitCore

final class ConversationAttachmentPanelTests: XCTestCase {
    func testPendingAttachmentIsShownBeforePreviouslySentAttachment() {
        let pending = PreparedAttachment(name: "draft.txt", kind: .text, summary: "Pending")
        let previous = PreparedAttachment(name: "report.pdf", kind: .pdf, summary: "Previous")

        let selected = ConversationAttachmentPanel.preferred(pending: [pending], current: [previous])

        XCTAssertEqual(selected?.name, "draft.txt")
    }

    func testPreviouslySentAttachmentRemainsVisibleWhenNothingIsPending() {
        let current = PreparedAttachment(name: "report.pdf", kind: .pdf, summary: "Current")

        let selected = ConversationAttachmentPanel.preferred(pending: [], current: [current])

        XCTAssertEqual(selected?.name, "report.pdf")
    }

    func testAttachmentPanelHasNoSelectionWhenBothListsAreEmpty() {
        XCTAssertNil(ConversationAttachmentPanel.preferred(pending: [], current: []))
    }
}

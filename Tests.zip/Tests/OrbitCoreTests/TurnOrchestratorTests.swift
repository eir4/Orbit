import XCTest
@testable import OrbitCore

private actor ScriptedClient: ModelClient {
    private var responses: [String]
    private var modelIDs: [String] = []

    init(_ responses: [String]) { self.responses = responses }

    func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String {
        modelIDs.append(modelID)
        guard !responses.isEmpty else { return "unexpected extra model call" }
        return responses.removeFirst()
    }

    func recordedModelIDs() -> [String] { modelIDs }
}

final class TurnOrchestratorTests: XCTestCase {
    func testMainModelReviewsBetweenSpecialistsAndThenFinishes() async throws {
        let client = ScriptedClient([
            #"{"action":"delegate","model_id":"vision","task":"inspect the image"}"#,
            "The image shows a blue panel.",
            #"{"action":"delegate","model_id":"reader","task":"read the attached document"}"#,
            "The document identifies the panel as revision B.",
            #"{"action":"finish","answer":"It is a revision B blue panel."}"#
        ])
        let main = LocalModel(id: "main")
        let workers = [LocalModel(id: "vision"), LocalModel(id: "reader")]
        let result = try await TurnOrchestrator(client: client).run(
            prompt: "Identify this panel.", mainModel: main, specialistModels: workers
        )

        let calls = await client.recordedModelIDs()
        XCTAssertEqual(calls, ["main", "vision", "main", "reader", "main"])
        XCTAssertEqual(result, "It is a revision B blue panel.")
    }

    func testUnknownSpecialistIsRejected() async throws {
        let client = ScriptedClient([
            #"{"action":"delegate","model_id":"missing","task":"inspect"}"#
        ])
        do {
            _ = try await TurnOrchestrator(client: client).run(
                prompt: "Inspect this.", mainModel: LocalModel(id: "main"), specialistModels: []
            )
            XCTFail("Expected an unknown-worker error")
        } catch let error as OrchestratorError {
            XCTAssertEqual(error, .unknownWorker("missing"))
        }
    }

    func testRetriesAnEmptyCoordinatorResponse() async throws {
        let client = ScriptedClient([
            "  ",
            #"{"action":"finish","answer":"Recovered answer."}"#
        ])
        let result = try await TurnOrchestrator(client: client).run(
            prompt: "Give a short answer.", mainModel: LocalModel(id: "main"), specialistModels: []
        )
        let calls = await client.recordedModelIDs()
        XCTAssertEqual(calls, ["main", "main"])
        XCTAssertEqual(result, "Recovered answer.")
    }

    func testEmptyCoordinatorFallsBackToASpecialistInsteadOfReturningBlank() async throws {
        let client = ScriptedClient([
            "",
            "",
            "The specialist's direct answer.",
            #"{"action":"finish","answer":"Synthesized from the specialist."}"#
        ])
        let result = try await TurnOrchestrator(client: client).run(
            prompt: "Complete a small task.",
            mainModel: LocalModel(id: "main"),
            specialistModels: [LocalModel(id: "worker")]
        )
        let calls = await client.recordedModelIDs()
        XCTAssertEqual(calls, ["main", "main", "worker", "main"])
        XCTAssertEqual(result, "Synthesized from the specialist.")
    }

    func testPlainSynthesisRetryRunsAfterCoordinatorReturnsEmptyAgain() async throws {
        let client = ScriptedClient([
            "",
            "",
            "The specialist found the result is 391.",
            "",
            "",
            "The product is 391, verified by both calculations."
        ])
        let result = try await TurnOrchestrator(client: client).run(
            prompt: "Calculate and verify 17 times 23.",
            mainModel: LocalModel(id: "main"),
            specialistModels: [LocalModel(id: "worker")]
        )
        let calls = await client.recordedModelIDs()
        XCTAssertEqual(calls, ["main", "main", "worker", "main", "main", "main"])
        XCTAssertEqual(result, "The product is 391, verified by both calculations.")
    }
}

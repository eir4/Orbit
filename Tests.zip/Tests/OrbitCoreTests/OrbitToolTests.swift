import XCTest
@testable import OrbitCore

final class OrbitToolTests: XCTestCase {
    func testBasicCalculatorHonorsPrecedenceAndParentheses() throws {
        let result = try BasicCalculatorTool().execute(arguments: [
            "expression": .string("(2 + 3) * 4 - 6 / 2")
        ])
        XCTAssertEqual(result, "17")
    }

    func testScientificCalculatorEvaluatesFunctionsAndConstants() throws {
        let result = try ScientificCalculatorTool().execute(arguments: [
            "expression": .string("sqrt(81) + sin(pi / 2) + log10(100)")
        ])
        XCTAssertEqual(result, "12")
    }

    func testAsciiCanvasReturnsValidatedRows() throws {
        let result = try ASCIICanvasTool().execute(arguments: [
            "rows": .array([.string(" /\\ "), .string("|__|")])
        ])
        XCTAssertTrue(result.contains("ASCII canvas · 4 × 2"))
        XCTAssertTrue(result.hasSuffix(" /\\ \n|__|"))
    }

    func testAsciiCanvasAllowsPrintableUnicodeAndUnknownToolsAreNotExecuted() throws {
        let result = try ASCIICanvasTool().execute(arguments: [
            "rows": .array([.string("╔café █╗")])
        ])
        XCTAssertTrue(result.hasSuffix("╔café █╗"))
        XCTAssertThrowsError(try ToolRegistry.builtIn.execute(name: "shell", arguments: [:]))
    }

    func testAsciiCanvasRejectsControlCharacters() {
        XCTAssertThrowsError(try ASCIICanvasTool().execute(arguments: [
            "rows": .array([.string("first\nsecond")])
        ]))
    }

    func testAsciiCanvasAcceptsMaximumDocumentedDimensions() throws {
        let row = String(repeating: "x", count: 256)
        let rows = Array(repeating: row, count: 80)
        let result = try ASCIICanvasTool().execute(arguments: ["rows": .array(rows.map(JSONValue.string))])
        XCTAssertTrue(result.contains("ASCII canvas · 256 × 80"))
        XCTAssertThrowsError(try ASCIICanvasTool().execute(arguments: [
            "rows": .array(Array(repeating: .string("x"), count: 81))
        ]))
        XCTAssertThrowsError(try ASCIICanvasTool().execute(arguments: [
            "rows": .array([.string(String(repeating: "x", count: 257))])
        ]))
    }

    func testAsciiCanvasExplainsRowsWhenModelUsesInputField() {
        XCTAssertThrowsError(try ASCIICanvasTool().execute(arguments: [
            "input": .string("Draw a house")
        ])) { error in
            XCTAssertEqual(error.localizedDescription, "Invalid tool argument: rows must be an array of literal text rows; do not use input.")
        }
    }

    func testModelCanRequestCalculatorAndReceivesItsResultBeforeAnswering() async throws {
        let client = ToolAwareModelClient(baseClient: ToolRequestThenAnswerClient())
        let answer = try await client.complete(
            modelID: "local-test",
            system: "Answer the question.",
            user: "What is 2 + 2?",
            images: []
        )
        XCTAssertEqual(answer, "The result is 4.")
    }

    func testRepeatedIdenticalCalculatorCallReturnsItsResult() async throws {
        let client = ToolAwareModelClient(baseClient: RepeatingCalculatorCallClient())
        let answer = try await client.complete(
            modelID: "local-test",
            system: "Use the calculator once and answer.",
            user: "What is 2 + 2?",
            images: []
        )
        XCTAssertEqual(answer, "4")
    }

    func testBareEquationForQuickTextIsCalculatedWithoutCallingTheModel() async throws {
        let client = ToolAwareModelClient(baseClient: UnexpectedModelCallClient())
        let answer = try await client.complete(
            modelID: "LFM2.5-230M-MXFP8",
            system: "Answer briefly.",
            user: "5+2",
            images: []
        )
        XCTAssertEqual(answer, "7")
    }

    func testAsciiCanvasInstructionsSpecifyRowsAndDisallowPromptField() {
        let instructions = ToolRegistry.builtIn.modelInstructions
        XCTAssertTrue(instructions.contains("rows argument as an array of literal text rows"))
        XCTAssertTrue(instructions.contains("Do not use an `input` field for `ascii_canvas`"))
    }

    func testModelCanRepairCanvasCallThatUsesPromptInsteadOfRows() async throws {
        let client = ToolAwareModelClient(baseClient: ASCIIInputThenRowsClient())
        let answer = try await client.complete(
            modelID: "local-test",
            system: "Draw a simple house.",
            user: "Draw a simple house.",
            images: []
        )
        XCTAssertEqual(answer, "Canvas ready.")
    }

    func testTruncatedToolCallWithMissingClosingBraceStillExecutes() async throws {
        let client = ToolAwareModelClient(baseClient: TruncatedCanvasRequestThenAnswerClient())
        let answer = try await client.complete(
            modelID: "local-test",
            system: "Draw a simple house.",
            user: "Draw a simple house.",
            images: []
        )
        XCTAssertEqual(answer, "Canvas ready.")
    }

    func testAsciiCanvasSupportsNFOScaleUnicodeArt() throws {
        let top = "╔" + String(repeating: "═", count: 231) + "╗"
        let middle = "║" + String(repeating: "█", count: 231) + "║"
        let bottom = "╚" + String(repeating: "═", count: 231) + "╝"
        let rows = [top] + Array(repeating: middle, count: 58) + [bottom]
        let result = try ASCIICanvasTool().execute(arguments: ["rows": .array(rows.map(JSONValue.string))])
        XCTAssertTrue(result.contains("ASCII canvas · 233 × 60"))
        XCTAssertTrue(result.hasSuffix(top + "\n" + Array(repeating: middle, count: 58).joined(separator: "\n") + "\n" + bottom))
    }

    func testToolInstructionsKeepSimpleSmileysOutOfCanvasCalls() {
        XCTAssertTrue(ToolRegistry.builtIn.modelInstructions.contains("For a smiley or kaomoji, answer directly without `ascii_canvas`."))
    }

    func testRepeatingCanvasCallReturnsTheFirstCanvasInsteadOfExhaustingBudget() async throws {
        let client = ToolAwareModelClient(baseClient: RepeatingCanvasCallClient())
        let answer = try await client.complete(
            modelID: "local-test",
            system: "Draw a smiley.",
            user: "Draw a smiley.",
            images: []
        )
        XCTAssertEqual(answer, "ASCII canvas · 3 × 1\n:-)")
    }
}

private struct ToolRequestThenAnswerClient: ModelClient {
    func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String {
        if user.contains("[Orbit tool result") { return "The result is 4." }
        return #"{"tool_call":"calculator","arguments":{"expression":"2+2"}}"#
    }
}

private struct TruncatedCanvasRequestThenAnswerClient: ModelClient {
    func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String {
        if user.contains("[Orbit tool result name=ascii_canvas]") { return "Canvas ready." }
        return ##"{"tool_call":"ascii_canvas","arguments":{"rows":["#","****","*******"]}"##
    }
}

private struct ASCIIInputThenRowsClient: ModelClient {
    func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String {
        if user.contains("ASCII canvas · 4 × 2") { return "Canvas ready." }
        if user.contains("[Orbit tool result") {
            return #"{"tool_call":"ascii_canvas","arguments":{"rows":[" /\\", "/__\\"]}}"#
        }
        return #"{"tool_call":"ascii_canvas","arguments":{"input":"Draw a simple house."}}"#
    }
}

private struct RepeatingCanvasCallClient: ModelClient {
    func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String {
        #"{"tool_call":"ascii_canvas","arguments":{"rows":[":-)"]}}"#
    }
}

private struct RepeatingCalculatorCallClient: ModelClient {
    func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String {
        #"{"tool_call":"calculator","arguments":{"expression":"2+2"}}"#
    }
}

private struct UnexpectedModelCallClient: ModelClient {
    func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String {
        throw OrbitToolError.unknownTool("Unexpected base-model call")
    }
}

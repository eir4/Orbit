import XCTest
@testable import OrbitCore

final class HuggingFaceRepoIDTests: XCTestCase {
    func testAcceptsOwnerModelAndCopiedHuggingFaceURL() throws {
        XCTAssertEqual(try HuggingFaceRepoID("google/medgemma-1.5-4b-it").value, "google/medgemma-1.5-4b-it")
        XCTAssertEqual(try HuggingFaceRepoID("https://huggingface.co/google/medgemma-1.5-4b-it").value, "google/medgemma-1.5-4b-it")
    }

    func testRejectsTraversalAndExtraPathComponents() {
        XCTAssertThrowsError(try HuggingFaceRepoID("../private"))
        XCTAssertThrowsError(try HuggingFaceRepoID("owner/repo/resolve/main"))
        XCTAssertThrowsError(try HuggingFaceRepoID("https://example.com/owner/repo"))
    }
}

import XCTest
@testable import OrbitCore

final class OrbitMotionTests: XCTestCase {
    func testOrbitStartsStaggeredAndWobblesWithoutLosingItsRadius() {
        let points = (0..<4).map { OrbitMotion.position(index: $0, count: 4, time: 0, radius: 300) }
        XCTAssertTrue(points[0].x > 0 && points[0].y > 0)
        XCTAssertTrue(points[1].x < 0 && points[1].y > 0)
        XCTAssertTrue(points[2].x < 0 && points[2].y < 0)
        XCTAssertTrue(points[3].x > 0 && points[3].y < 0)

        let later = OrbitMotion.position(index: 0, count: 4, time: 3, radius: 300)
        XCTAssertNotEqual(points[0], later)
        let radius = hypot(later.x, later.y)
        XCTAssertGreaterThan(radius, 294)
        XCTAssertLessThan(radius, 306)
    }

    func testThinkingWaveMovesVerticallyWhilePreservingModelOrder() {
        let left = OrbitMotion.wavePosition(index: 0, count: 4, time: 0, spacing: 160, amplitude: 36)
        let right = OrbitMotion.wavePosition(index: 3, count: 4, time: 0, spacing: 160, amplitude: 36)
        let laterLeft = OrbitMotion.wavePosition(index: 0, count: 4, time: 2, spacing: 160, amplitude: 36)

        XCTAssertLessThan(left.x, right.x)
        XCTAssertEqual(left.x, laterLeft.x)
        XCTAssertNotEqual(left.y, laterLeft.y)
        XCTAssertLessThanOrEqual(abs(left.y), 44)
    }

    func testCoordinatorPulseVisitsOneModelAtATime() {
        let firstEarly = OrbitMotion.coordinatorPulse(index: 0, count: 4, time: 0.7)
        let secondEarly = OrbitMotion.coordinatorPulse(index: 1, count: 4, time: 0.7)
        let firstLate = OrbitMotion.coordinatorPulse(index: 0, count: 4, time: 1.75)
        let secondLate = OrbitMotion.coordinatorPulse(index: 1, count: 4, time: 1.75)

        XCTAssertGreaterThan(firstEarly, secondEarly)
        XCTAssertGreaterThan(secondLate, firstLate)
    }

    func testHomeOrbitLeavesTheComposerClearForSeveralModelCounts() {
        let centerHalfWidth = 210.0
        let nodeHalfWidth = 66.0
        let centerHalfHeight = 60.0
        let nodeHalfHeight = 34.0

        for count in [4, 5, 8, 12] {
            for time in [0.0, 10.0, 45.0, 90.0] {
                for index in 0..<count {
                    let point = OrbitMotion.position(index: index, count: count, time: time, radius: 300)
                    let clearHorizontally = abs(point.x) >= centerHalfWidth + nodeHalfWidth
                    let clearVertically = abs(point.y) >= centerHalfHeight + nodeHalfHeight
                    XCTAssertTrue(clearHorizontally || clearVertically, "model node intersects the composer at count=\(count), time=\(time)")
                }
            }
        }
    }

    func testWaveMovesVerticallyWithoutChangingLeftToRightOrder() {
        let atStart = (0..<4).map { OrbitMotion.wavePosition(index: $0, count: 4, time: 0, spacing: 180, amplitude: 25) }
        let later = (0..<4).map { OrbitMotion.wavePosition(index: $0, count: 4, time: 1.5, spacing: 180, amplitude: 25) }
        XCTAssertEqual(atStart.map(\.x), later.map(\.x))
        XCTAssertEqual(atStart.map(\.x), atStart.map(\.x).sorted())
        XCTAssertNotEqual(atStart.map(\.y), later.map(\.y))
    }

    func testCoordinatorPulseBreathesOneNodeAtATimeInSequence() {
        let count = 4
        let firstPeak = (0..<count).map { OrbitMotion.coordinatorPulse(index: $0, count: count, time: 0.625, stepDuration: 1.25) }
        XCTAssertEqual(firstPeak[0], 1, accuracy: 0.001)
        XCTAssertTrue(firstPeak.dropFirst().allSatisfy { $0 <= 0.05 })

        let secondPeak = (0..<count).map { OrbitMotion.coordinatorPulse(index: $0, count: count, time: 1.875, stepDuration: 1.25) }
        XCTAssertEqual(secondPeak[1], 1, accuracy: 0.001)
        XCTAssertTrue(secondPeak.enumerated().allSatisfy { $0.offset == 1 || $0.element <= 0.05 })
    }
}


import Foundation
import OrbitCore
import VMLXHub

/// Downloads a Hugging Face model snapshot into Orbit's LocalAI library.
/// Authentication is delegated to the Hub SDK's environment provider, which honors the user's existing HF CLI token.
public actor HuggingFaceModelDownloader {
    private let downloadRoot: URL

    public init(downloadRoot: URL = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("LocalAI", isDirectory: true)) {
        self.downloadRoot = downloadRoot
    }

    @discardableResult
    public func download(
        repoID: String,
        revision: String = "main",
        progressHandler: @escaping @Sendable (Double, Double?) -> Void = { _, _ in }
    ) async throws -> URL {
        let repo = try HuggingFaceRepoID(repoID)
        let hub = HubApi(downloadBase: downloadRoot, useBackgroundSession: false, useOfflineMode: false)
        let snapshot = try await hub.snapshot(from: repo.value, revision: revision, matching: []) { progress, speed in
            progressHandler(progress.fractionCompleted, speed)
        }
        try Task.checkCancellation()
        return snapshot
    }
}

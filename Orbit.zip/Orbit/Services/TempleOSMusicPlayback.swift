import AVFoundation
import SwiftUI

struct TempleOSMusicSequence {
    let notes: [String]
    let tempo: Int

    static func parse(_ text: String) -> TempleOSMusicSequence? {
        let lines = text.components(separatedBy: .newlines)
        guard let header = lines.first, header.hasPrefix("TempleOS music notes ·") else { return nil }
        let tempoField = header.components(separatedBy: "tempo=").dropFirst().first ?? ""
        let tempoDigits = String(tempoField.prefix(while: \.isNumber))
        guard let tempo = Int(tempoDigits), (40...180).contains(tempo) else { return nil }
        let notes = lines.dropFirst().flatMap { $0.split(whereSeparator: \.isWhitespace).map(String.init) }
        guard !notes.isEmpty, notes.allSatisfy({ midiNumber(for: $0) != nil }) else { return nil }
        return TempleOSMusicSequence(notes: notes, tempo: tempo)
    }

    static func midiNumber(for note: String) -> Int? {
        guard let octave = Int(note.suffix(1)) else { return nil }
        let pitchName = String(note.dropLast())
        let pitches = ["C": 0, "C♯": 1, "D": 2, "D♯": 3, "E": 4, "F": 5, "F♯": 6, "G": 7, "G♯": 8, "A": 9, "A♯": 10, "B": 11]
        guard let pitch = pitches[pitchName] else { return nil }
        return (octave + 1) * 12 + pitch
    }
}

@MainActor
private final class TempleOSMelodyPlayer: ObservableObject {
    @Published private(set) var isPlaying = false

    private let engine = AVAudioEngine()
    private let player = AVAudioPlayerNode()
    private var attached = false

    func play(_ sequence: TempleOSMusicSequence) {
        player.stop()
        if engine.isRunning { engine.stop() }
        guard let format = AVAudioFormat(standardFormatWithSampleRate: 44_100, channels: 1) else { return }
        if !attached {
            engine.attach(player)
            engine.connect(player, to: engine.mainMixerNode, format: format)
            attached = true
        }

        let sampleRate = 44_100.0
        let framesPerNote = max(1, Int(sampleRate * 60.0 / Double(sequence.tempo)))
        for note in sequence.notes {
            guard let midi = TempleOSMusicSequence.midiNumber(for: note),
                  let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(framesPerNote)),
                  let samples = buffer.floatChannelData?.pointee else { continue }
            buffer.frameLength = AVAudioFrameCount(framesPerNote)
            let frequency = 440.0 * pow(2.0, Double(midi - 69) / 12.0)
            let attackFrames = max(1, Int(sampleRate * 0.012))
            let releaseFrames = max(1, Int(sampleRate * 0.07))
            for frame in 0..<framesPerNote {
                let attack = min(1.0, Double(frame) / Double(attackFrames))
                let release = min(1.0, Double(framesPerNote - frame) / Double(releaseFrames))
                let envelope = min(attack, release)
                let wave = sin(2.0 * Double.pi * frequency * Double(frame) / sampleRate)
                samples[frame] = Float(wave * envelope * 0.16)
            }
            player.scheduleBuffer(buffer)
        }

        do {
            try engine.start()
            player.play()
            isPlaying = true
            let duration = Double(sequence.notes.count) * 60.0 / Double(sequence.tempo)
            DispatchQueue.main.asyncAfter(deadline: .now() + duration) { [weak self] in
                guard let self else { return }
                self.isPlaying = false
                self.engine.stop()
            }
        } catch {
            player.stop()
            isPlaying = false
        }
    }

    func stop() {
        player.stop()
        if engine.isRunning { engine.stop() }
        isPlaying = false
    }
}

struct TempleOSMusicPlaybackButton: View {
    let sequence: TempleOSMusicSequence
    @StateObject private var player = TempleOSMelodyPlayer()

    var body: some View {
        Button {
            if player.isPlaying {
                player.stop()
            } else {
                player.play(sequence)
            }
        } label: {
            Label(player.isPlaying ? "Stop melody" : "Play melody", systemImage: player.isPlaying ? "stop.fill" : "play.fill")
        }
        .buttonStyle(.bordered)
        .controlSize(.mini)
    }
}

import Foundation
import PDFKit
import UniformTypeIdentifiers
import OrbitCore

public enum AttachmentPreparationError: LocalizedError {
    case tooLarge(String)
    case unreadable(String)

    public var errorDescription: String? {
        switch self {
        case .tooLarge(let name): "\(name) is too large for this first build (50 MB limit)."
        case .unreadable(let name): "Couldn't read \(name)."
        }
    }
}

public enum AttachmentService {
    private static let maxFileBytes = 50 * 1_024 * 1_024
    private static let maxTextCharacters = 100_000

    public static func prepare(_ url: URL) throws -> PreparedAttachment {
        let hasAccess = url.startAccessingSecurityScopedResource()
        defer { if hasAccess { url.stopAccessingSecurityScopedResource() } }

        let values = try? url.resourceValues(forKeys: [.fileSizeKey])
        let byteCount = values?.fileSize ?? 0
        guard byteCount <= maxFileBytes else { throw AttachmentPreparationError.tooLarge(url.lastPathComponent) }
        guard let data = try? Data(contentsOf: url, options: [.mappedIfSafe]) else {
            throw AttachmentPreparationError.unreadable(url.lastPathComponent)
        }
        let inferredKind = AttachmentKind.infer(fileExtension: url.pathExtension)

        switch inferredKind {
        case .pdf:
            return preparePDF(url, byteCount: data.count)
        case .image:
            let mime = UTType(filenameExtension: url.pathExtension)?.preferredMIMEType ?? "image/jpeg"
            let imageURL = "data:\(mime);base64,\(data.base64EncodedString())"
            return PreparedAttachment(name: url.lastPathComponent, kind: .image, summary: "Image attached for a visual specialist.", imageDataURL: imageURL, byteCount: data.count)
        case .text:
            guard let string = String(data: data, encoding: .utf8) else {
                return prepareHex(url.lastPathComponent, data: data)
            }
            let excerpt = String(string.prefix(maxTextCharacters))
            let note = string.count > maxTextCharacters ? "Text clipped to the first \(maxTextCharacters) characters." : "UTF-8 text extracted."
            return PreparedAttachment(name: url.lastPathComponent, kind: .text, summary: note, text: excerpt, byteCount: data.count)
        case .hex:
            return prepareHex(url.lastPathComponent, data: data)
        case .other:
            if let string = String(data: data, encoding: .utf8), !string.unicodeScalars.contains(where: { $0.value == 0 }) {
                return PreparedAttachment(name: url.lastPathComponent, kind: .text, summary: "Unrecognized extension; UTF-8 text detected.", text: String(string.prefix(maxTextCharacters)), byteCount: data.count)
            }
            return prepareHex(url.lastPathComponent, data: data)
        }
    }

    private static func preparePDF(_ url: URL, byteCount: Int) -> PreparedAttachment {
        guard let document = PDFDocument(url: url) else {
            return PreparedAttachment(name: url.lastPathComponent, kind: .pdf, summary: "PDF couldn't be parsed; no text extracted.", byteCount: byteCount)
        }
        var pages: [String] = []
        var remaining = maxTextCharacters
        for index in 0..<min(document.pageCount, 100) where remaining > 0 {
            guard let text = document.page(at: index)?.string, !text.isEmpty else { continue }
            let pageText = String(text.prefix(remaining))
            pages.append("[Page \(index + 1)]\n\(pageText)")
            remaining -= pageText.count
        }
        let extracted = pages.joined(separator: "\n\n")
        let summary: String
        if extracted.isEmpty {
            summary = "No selectable text found. This may be a scanned PDF; OCR/vision routing is not implemented yet."
        } else {
            summary = "Extracted selectable text from up to 100 pages; page labels retained."
        }
        return PreparedAttachment(name: url.lastPathComponent, kind: .pdf, summary: summary, text: extracted, byteCount: byteCount)
    }

    private static func prepareHex(_ name: String, data: Data) -> PreparedAttachment {
        let shown = min(data.count, 4_096)
        let preview = HexFormatter.preview(data, maxBytes: shown)
        let summary = "Hex view shows bytes 0–\(max(0, shown - 1)) of \(data.count); ASCII gutter included."
        return PreparedAttachment(name: name, kind: .hex, summary: summary, text: preview, byteCount: data.count)
    }
}

import Foundation
import Combine
import Darwin
import Metal

struct ResourceUsageSnapshot {
    var appCPUPercent: Double?
    var appPhysicalBytes: UInt64?
    var totalPhysicalBytes: UInt64
    var metalAllocatedBytes: UInt64?
    var metalWorkingSetBytes: UInt64?
}

@MainActor
final class ResourceUsageMonitor: ObservableObject {
    @Published private(set) var snapshot = ResourceUsageSnapshot(
        appCPUPercent: nil,
        appPhysicalBytes: nil,
        totalPhysicalBytes: ProcessInfo.processInfo.physicalMemory,
        metalAllocatedBytes: nil,
        metalWorkingSetBytes: nil
    )

    private let device = MTLCreateSystemDefaultDevice()
    private var previousCPUSeconds: Double?
    private var previousUptime: Double?
    private var sampler: Task<Void, Never>?

    init() {
        sampler = Task { [weak self] in
            while !Task.isCancelled {
                guard let self else { return }
                self.sample()
                try? await Task.sleep(for: .seconds(1))
            }
        }
    }

    deinit {
        sampler?.cancel()
    }

    private func sample() {
        let uptime = ProcessInfo.processInfo.systemUptime
        let cpuSeconds = processCPUSeconds()
        let cpuPercent: Double?
        if let cpuSeconds, let previousCPUSeconds, let previousUptime {
            let elapsed = uptime - previousUptime
            let cpuDelta = max(0, cpuSeconds - previousCPUSeconds)
            let cores = Double(max(1, ProcessInfo.processInfo.processorCount))
            cpuPercent = elapsed > 0 ? min(100, max(0, cpuDelta / elapsed * 100 / cores)) : nil
        } else {
            cpuPercent = nil
        }
        previousCPUSeconds = cpuSeconds
        previousUptime = uptime

        snapshot = ResourceUsageSnapshot(
            appCPUPercent: cpuPercent,
            appPhysicalBytes: physicalFootprintBytes(),
            totalPhysicalBytes: ProcessInfo.processInfo.physicalMemory,
            metalAllocatedBytes: device.map { UInt64(max(0, $0.currentAllocatedSize)) },
            metalWorkingSetBytes: device.map { UInt64(max(0, $0.recommendedMaxWorkingSetSize)) }
        )
    }

    private func processCPUSeconds() -> Double? {
        var usage = rusage()
        guard getrusage(RUSAGE_SELF, &usage) == 0 else { return nil }
        let user = Double(usage.ru_utime.tv_sec) + Double(usage.ru_utime.tv_usec) / 1_000_000
        let system = Double(usage.ru_stime.tv_sec) + Double(usage.ru_stime.tv_usec) / 1_000_000
        return user + system
    }

    private func physicalFootprintBytes() -> UInt64? {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.stride / MemoryLayout<natural_t>.stride)
        let result = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { rebound in
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), rebound, &count)
            }
        }
        guard result == KERN_SUCCESS else { return nil }
        return UInt64(info.phys_footprint)
    }
}

import CoreImage
import Foundation
import OrbitCore
import VMLX
import VMLXTokenizers

/// Owns local model inference inside Orbit. Only one bundle is resident at a time.
public actor LocalMLXRuntime: ModelClient {
    public let modelRoots: [URL]
    public var modelRoot: URL { modelRoots.first ?? ModelStore.defaultRoot() }
    public private(set) var overBudgetModelCount = 0
    private var descriptors: [String: LocalModelDescriptor] = [:]
    private var overBudgetDescriptors: [String: LocalModelDescriptor] = [:]
    private var activeModelID: String?
    private var activeContainer: ModelContainer?
    private let tokenizerLoader = OrbitTokenizerLoader()

    public init(modelRoots: [URL] = ModelStore.defaultRoots()) {
        self.modelRoots = modelRoots
    }

    public func discoverModels() -> [LocalModel] {
        let allModels = ModelStore.discover(in: modelRoots)
        let partition = ModelStore.partitionByWeightBudget(allModels, maximumWeightBytes: Self.safeWeightBudget)
        descriptors = Dictionary(uniqueKeysWithValues: partition.loadable.map { ($0.id, $0) })
        overBudgetDescriptors = Dictionary(uniqueKeysWithValues: partition.overBudget.map { ($0.id, $0) })
        overBudgetModelCount = partition.overBudget.count
        return partition.loadable.map { LocalModel(id: $0.id, ownedBy: "local") }
    }

    public func complete(modelID: String, system: String, user: String, images: [String]) async throws -> String {
        if descriptors[modelID] == nil { _ = discoverModels() }
        guard let descriptor = descriptors[modelID] else {
            if let model = overBudgetDescriptors[modelID] {
                throw LocalRuntimeError.modelExceedsMemoryBudget(model.id, model.weightByteCount, Self.safeWeightBudget)
            }
            throw LocalRuntimeError.modelNotFound(modelID)
        }

        let container: ModelContainer
        if activeModelID == modelID, let activeContainer {
            container = activeContainer
        } else {
            // Free the previous model before the next one is loaded on the Mac's 8 GB unified memory.
            activeContainer = nil
            activeModelID = nil
            let loaded = try await loadModelContainer(from: descriptor.directory, using: tokenizerLoader)
            activeContainer = loaded
            activeModelID = modelID
            container = loaded
        }

        let tokenLimit = system.contains("lightweight coordinator") ? 640 : 1_200
        let session = ChatSession(
            container,
            instructions: system,
            generateParameters: GenerateParameters(maxTokens: tokenLimit, temperature: 0.2)
        )
        let visualInputs = try images.map(Self.decodeImageDataURL)
        return try await session.respond(to: user, images: visualInputs, videos: [])
    }

    public func unloadActiveModel() {
        activeContainer = nil
        activeModelID = nil
    }

    private static var safeWeightBudget: UInt64 {
        (ProcessInfo.processInfo.physicalMemory / 10) * 7
    }

    private static func decodeImageDataURL(_ value: String) throws -> UserInput.Image {
        guard let comma = value.firstIndex(of: ","),
              value[..<comma].lowercased().hasPrefix("data:image/"),
              let data = Data(base64Encoded: String(value[value.index(after: comma)...])),
              let image = CIImage(data: data) else {
            throw LocalRuntimeError.invalidImagePayload
        }
        return .ciImage(image)
    }
}

private struct OrbitTokenizerLoader: TokenizerLoader, Sendable {
    func load(from directory: URL) async throws -> any MLXLMCommon.Tokenizer {
        let tokenizer = try await AutoTokenizer.from(modelFolder: directory)
        return OrbitTokenizerBridge(upstream: tokenizer)
    }
}

private struct OrbitTokenizerBridge: MLXLMCommon.Tokenizer, @unchecked Sendable {
    let upstream: any VMLXTokenizers.Tokenizer

    func encode(text: String, addSpecialTokens: Bool) -> [Int] {
        upstream.encode(text: text, addSpecialTokens: addSpecialTokens)
    }

    func decode(tokenIds: [Int], skipSpecialTokens: Bool) -> String {
        upstream.decode(tokens: tokenIds, skipSpecialTokens: skipSpecialTokens)
    }

    func convertTokenToId(_ token: String) -> Int? { upstream.convertTokenToId(token) }
    func convertIdToToken(_ id: Int) -> String? { upstream.convertIdToToken(id) }
    var bosToken: String? { upstream.bosToken }
    var eosToken: String? { upstream.eosToken }
    var unknownToken: String? { upstream.unknownToken }

    func applyChatTemplate(
        messages: [[String: any Sendable]],
        tools: [[String: any Sendable]]?,
        additionalContext: [String: any Sendable]?
    ) throws -> [Int] {
        try upstream.applyChatTemplate(
            messages: messages,
            chatTemplate: nil,
            addGenerationPrompt: true,
            truncation: false,
            maxLength: nil,
            tools: tools,
            additionalContext: additionalContext
        )
    }
}

public enum LocalRuntimeError: LocalizedError {
    case modelNotFound(String)
    case modelExceedsMemoryBudget(String, UInt64, UInt64)
    case invalidImagePayload

    public var errorDescription: String? {
        switch self {
        case .modelNotFound(let id): "Local model bundle not found: \(id). Refresh the model folder and try again."
        case .modelExceedsMemoryBudget(let id, let weightBytes, let budgetBytes):
            String(format: "%@ has %.1f GiB of weights, above Orbit's safe in-process memory budget of %.1f GiB. Use a smaller or quantized MLX bundle.", id, Double(weightBytes) / 1_073_741_824, Double(budgetBytes) / 1_073_741_824)
        case .invalidImagePayload: "Could not decode an attached image for the local vision model."
        }
    }
}

import AppKit
import SwiftUI
import UniformTypeIdentifiers
import OrbitCore

struct OrbitView: View {
    @EnvironmentObject private var state: OrbitAppState
    @State private var showFileImporter = false
    @State private var showConversationManager = false
    @State private var showModelDownloader = false
    @State private var showTaskManager = false
    @State private var showTempleOSPoly = false
    @State private var showTempleOSElephant = false
    @State private var showTempleOSBSpline = false
    @State private var hexPreview: PreparedAttachment?

    var body: some View {
        Group {
            if state.messages.isEmpty {
                VStack(spacing: 0) {
                    header
                    ModelOrbitView(layout: .centered) { homeComposer }
                        .environmentObject(state)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            } else {
                conversationWorkspace
            }
        }
        .frame(minWidth: 820, minHeight: 740)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
        .task { await state.refreshModels() }
        .fileImporter(isPresented: $showFileImporter, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in
            switch result {
            case .success(let urls): Task { await state.addAttachments(urls) }
            case .failure(let error): state.errorMessage = error.localizedDescription
            }
        }
        .sheet(item: $hexPreview) { attachment in
            HexInspectorView(attachment: attachment)
                .frame(minWidth: 700, minHeight: 460)
        }
        .sheet(isPresented: $showConversationManager) {
            ConversationManagerView()
                .environmentObject(state)
        }
        .sheet(isPresented: $showModelDownloader) {
            HuggingFaceDownloadView()
                .environmentObject(state)
        }
        .sheet(isPresented: $showTaskManager) {
            TaskManagerView()
                .environmentObject(state)
        }
        .sheet(isPresented: $showTempleOSPoly) {
            TempleOSPolyView()
        }
        .sheet(isPresented: $showTempleOSElephant) {
            TempleOSElephantView()
        }
        .sheet(isPresented: $showTempleOSBSpline) {
            TempleOSBSplineView()
        }
        .alert("Orbit", isPresented: Binding(get: { state.errorMessage != nil }, set: { if !$0 { state.errorMessage = nil } })) {
            Button("OK", role: .cancel) { state.errorMessage = nil }
        } message: {
            Text(state.errorMessage ?? "")
        }
    }

    private var conversationWorkspace: some View {
        HStack(spacing: 0) {
            ConversationSidebarView(
                showConversationManager: $showConversationManager,
                showTempleOSPoly: $showTempleOSPoly,
                showTempleOSElephant: $showTempleOSElephant,
                showTempleOSBSpline: $showTempleOSBSpline
            )
                .environmentObject(state)
                .frame(width: 174)
            Divider()
            VStack(spacing: 0) {
                if state.isBusy {
                    ModelOrbitView(layout: .wave) { EmptyView() }
                        .environmentObject(state)
                        .frame(height: 84)
                        .animation(.easeInOut(duration: 0.35), value: state.isBusy)
                } else {
                    conversationModeHeader
                }
                Divider()
                conversation
                composer
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            Divider()
            ConversationUtilityRail(
                showTaskManager: $showTaskManager,
                onAddModel: { showModelDownloader = true },
                onRefreshModels: { Task { await state.refreshModels() } },
                onAddFile: { showFileImporter = true },
                onInspectHex: { hexPreview = $0 }
            )
            .environmentObject(state)
            .frame(width: 188)
        }
    }

    private var conversationModeHeader: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(Color(red: 0.51, green: 0.35, blue: 0.40))
                .frame(width: 7, height: 7)
            Text(state.directModel == nil ? "SQUAD CONVERSATION" : "DIRECT MODEL")
                .font(.system(size: 9, weight: .bold, design: .monospaced))
                .tracking(0.7)
            Spacer(minLength: 8)
            Text(activeModelDescription)
                .font(.system(size: 10, weight: .medium))
                .lineLimit(1)
                .truncationMode(.middle)
                .foregroundStyle(.secondary)
            if state.directModel != nil {
                Button("Return to squad") { state.returnToSquad() }
                    .font(.system(size: 9, weight: .medium))
                    .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 42)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
    }

    private var header: some View {
        VStack(spacing: 2) {
            HStack(spacing: 12) {
                Menu {
                    Button("New conversation", systemImage: "square.and.pencil") { state.startNewConversation() }
                    .disabled(state.isBusy)
                    Button("Conversation manager…", systemImage: "tray.full") { showConversationManager = true }
                    Divider()
                    Button("3D Poly demo", systemImage: "cube.transparent") { showTempleOSPoly = true }
                    Button("Elephant demo", systemImage: "hare") { showTempleOSElephant = true }
                    Button("B-spline demo", systemImage: "point.topleft.down.curvedto.point.bottomright.up") { showTempleOSBSpline = true }
                    Button("Generate God word", systemImage: "sparkles") { state.generateGodWord() }
                    if !state.activeConversations.isEmpty { Divider() }
                    ForEach(state.activeConversations) { conversation in
                        Button {
                            state.openConversation(conversation)
                        } label: {
                            if conversation.isPinned {
                                Label(conversation.title, systemImage: "pin.fill")
                            } else {
                                Text(conversation.title)
                            }
                        }
                        .disabled(state.isBusy)
                    }
                } label: {
                    Image(systemName: "line.3.horizontal")
                        .font(.system(size: 15, weight: .medium))
                        .frame(width: 34, height: 34)
                        .background(.white.opacity(0.82), in: Circle())
                        .overlay(Circle().stroke(Color.black.opacity(0.07), lineWidth: 1))
                }
                .menuStyle(.borderlessButton)
                .help("Past conversations")

                VStack(alignment: .leading, spacing: 1) {
                    Text("ORBIT")
                        .font(.system(size: 11, weight: .bold, design: .rounded))
                        .tracking(2.2)
                    Text("LOCAL MODEL SQUAD")
                        .font(.system(size: 9, weight: .medium, design: .monospaced))
                        .tracking(0.8)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                HStack(spacing: 6) {
                    Circle().fill(state.connectionStatus.contains("LOCAL") ? Color(red: 0.32, green: 0.55, blue: 0.40) : .orange).frame(width: 6, height: 6)
                    Text(state.connectionStatus)
                        .font(.system(size: 9, weight: .medium, design: .monospaced))
                        .tracking(0.4)
                        .help("Scans ~/MLXModels and ~/LocalAI, then lists only bundles with a recognized generative config, tokenizer, and safetensors/NPZ weights. GGUF and image-only weights are not loadable; bundles above the safe memory budget are excluded.")
                }
                .foregroundStyle(.secondary)
                Button { showModelDownloader = true } label: {
                    Image(systemName: "plus.circle").font(.system(size: 12, weight: .medium)).frame(width: 30, height: 30)
                }
                .buttonStyle(.plain)
                .help("Add a model from Hugging Face")
                Button { Task { await state.refreshModels() } } label: {
                    Image(systemName: "arrow.clockwise").font(.system(size: 12, weight: .medium)).frame(width: 30, height: 30)
                }
                .buttonStyle(.plain)
                .help("Refresh local models")
            }
            .padding(.horizontal, 22)

            if !state.tasks.isEmpty {
                HStack(spacing: 7) {
                    Spacer()
                    Text("Tasks: \(state.tasks.count), completed \(state.completedTaskCount)")
                        .font(.system(size: 9, weight: .medium, design: .monospaced))
                        .foregroundStyle(.secondary)
                    Button("See more") { showTaskManager = true }
                        .font(.system(size: 9, weight: .semibold))
                        .buttonStyle(.plain)
                        .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                        .underline()
                }
                .padding(.horizontal, 22)
                .padding(.top, 2)
            }
        }
        .padding(.top, 14)
        .padding(.bottom, 7)
    }

    private var homeComposer: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 9) {
                Image(systemName: state.directModel == nil ? "circle.hexagongrid.fill" : "bolt.circle.fill")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                VStack(alignment: .leading, spacing: 2) {
                    Text(state.directModel == nil ? "COORDINATOR" : "DIRECT MODEL")
                        .font(.system(size: 8, weight: .bold, design: .monospaced))
                        .tracking(1)
                    Text(activeModelDescription)
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 8)
                if state.directModel != nil {
                    Button("Squad") { state.returnToSquad() }
                        .font(.system(size: 9, weight: .medium))
                        .buttonStyle(.plain)
                        .help("Return to the coordinator")
                }
            }

            pendingAttachmentsStrip

            HStack(alignment: .bottom, spacing: 10) {
                attachmentButton(size: 38)
                TextField("Give the coordinator a goal…", text: $state.prompt, axis: .vertical)
                    .lineLimit(2...3)
                    .textFieldStyle(.plain)
                    .padding(.horizontal, 13)
                    .padding(.vertical, 10)
                    .frame(minHeight: 50)
                    .background(Color(red: 0.98, green: 0.973, blue: 0.965), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                    .onSubmit { state.send() }
                sendButton(size: 38)
            }
        }
        .padding(15)
        .frame(width: 420)
        .background(.white, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.black.opacity(0.08), lineWidth: 1))
        .shadow(color: .black.opacity(0.055), radius: 16, y: 6)
    }

    private var activeModelDescription: String {
        if let direct = state.directModel { return state.appearance(for: direct).shortDescription }
        return state.mainModel.map { state.appearance(for: $0).shortDescription } ?? "Choose a coordinator"
    }

    private var coordinatorButton: some View {
        Menu {
            ForEach(state.models) { model in
                Button("\(state.appearance(for: model).shortDescription) · \(model.displayName)") { state.setMainModel(model) }
            }
        } label: {
            VStack(spacing: 5) {
                Image(systemName: "circle.hexagongrid.fill")
                    .font(.system(size: 18, weight: .light))
                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                Text("COORDINATOR")
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .tracking(1.2)
                Text(activeModelDescription)
                    .font(.system(size: 10, weight: .medium))
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .frame(maxWidth: 125)
                Text("select coordinator")
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
            }
            .frame(width: 150, height: 102)
            .background(.white.opacity(0.96), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color(red: 0.78, green: 0.65, blue: 0.68), lineWidth: 1))
            .shadow(color: .black.opacity(0.045), radius: 10, y: 4)
        }
        .menuStyle(.borderlessButton)
        .help("Choose the coordinator model")
    }

    @ViewBuilder private var pendingAttachmentsStrip: some View {
        if !state.pendingAttachments.isEmpty {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 7) {
                    ForEach(state.pendingAttachments) { attachment in
                        HStack(spacing: 7) {
                            Image(systemName: icon(for: attachment.kind)).font(.system(size: 10))
                            Text(attachment.name).font(.system(size: 10, weight: .medium)).lineLimit(1)
                            if attachment.kind == .hex {
                                Button("Hex") { hexPreview = attachment }
                                    .font(.system(size: 9, weight: .semibold, design: .monospaced))
                                    .buttonStyle(.plain)
                            }
                            Button { state.removeAttachment(attachment) } label: {
                                Image(systemName: "xmark.circle.fill").font(.system(size: 11))
                            }.buttonStyle(.plain)
                        }
                        .padding(.horizontal, 9)
                        .padding(.vertical, 6)
                        .background(Color(red: 0.973, green: 0.961, blue: 0.945), in: Capsule())
                        .overlay(Capsule().stroke(Color.black.opacity(0.08), lineWidth: 1))
                    }
                }
            }
        }
    }

    private func attachmentButton(size: CGFloat) -> some View {
        Button { showFileImporter = true } label: {
            Image(systemName: "paperclip").font(.system(size: 15)).frame(width: size, height: size)
        }
        .buttonStyle(.plain)
        .background(.white, in: Circle())
        .overlay(Circle().stroke(Color.black.opacity(0.08), lineWidth: 1))
        .help("Attach text, image, PDF, or binary file")
    }

    private func sendButton(size: CGFloat) -> some View {
        Button { state.send() } label: {
            Image(systemName: "arrow.up")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: size, height: size)
                .background(Color(red: 0.51, green: 0.35, blue: 0.40), in: Circle())
        }
        .buttonStyle(.plain)
        .keyboardShortcut(.return, modifiers: .command)
        .disabled(state.isBusy || (state.prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && state.pendingAttachments.isEmpty))
        .opacity(state.isBusy ? 0.5 : 1)
        .accessibilityLabel("Send message")
        .help("Send")
    }

    private var conversation: some View {
        GeometryReader { geometry in
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        ForEach(state.messages) { entry in
                            MessageBubble(entry: entry)
                                .id(entry.id)
                        }
                        if state.isBusy {
                            HStack(spacing: 7) {
                                ProgressView().controlSize(.small)
                                Text("Local models taking turns")
                                    .font(.system(size: 10, design: .monospaced))
                                    .foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity, alignment: .center)
                        }
                    }
                    .frame(width: min(820, max(0, geometry.size.width - 44)), alignment: .leading)
                    .frame(width: geometry.size.width, alignment: .center)
                    .padding(.vertical, 14)
                }
                .onChange(of: state.messages.count) { _, _ in
                    if let last = state.messages.last { withAnimation(.easeOut(duration: 0.2)) { proxy.scrollTo(last.id, anchor: .bottom) } }
                }
            }
        }
        .frame(maxHeight: .infinity)
    }

    private var composer: some View {
        VStack(spacing: 8) {
            pendingAttachmentsStrip
            if let direct = state.directModel {
                HStack(spacing: 7) {
                    Text("DIRECT · \(direct.displayName)").font(.system(size: 9, weight: .semibold, design: .monospaced)).tracking(0.5)
                    Text("Squad bypassed").font(.system(size: 9)).foregroundStyle(.secondary)
                    Button("Return to squad") { state.returnToSquad() }.font(.system(size: 9, weight: .medium)).buttonStyle(.plain)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            HStack(alignment: .bottom, spacing: 10) {
                attachmentButton(size: 38)
                TextField("Ask the main model to organize the work…", text: $state.prompt, axis: .vertical)
                    .lineLimit(1...4)
                    .textFieldStyle(.plain)
                    .padding(.horizontal, 13)
                    .padding(.vertical, 10)
                    .background(.white, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.black.opacity(0.08), lineWidth: 1))
                    .onSubmit { state.send() }
                sendButton(size: 38)
            }
        }
        .padding(.horizontal, 22)
        .padding(.top, 9)
        .padding(.bottom, 16)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
    }

    private func icon(for kind: AttachmentKind) -> String {
        switch kind {
        case .text: "doc.text"
        case .image: "photo"
        case .pdf: "doc.richtext"
        case .hex: "number"
        case .other: "doc"
        }
    }
}

private struct MessageBubble: View {
    let entry: ConversationEntry

    var body: some View {
        HStack(spacing: 0) {
            switch entry.kind {
            case .user:
                Spacer(minLength: 60)
                bubble
            case .activity:
                Spacer(minLength: 0)
                bubble
                Spacer(minLength: 0)
            case .assistant, .specialist:
                bubble
                Spacer(minLength: 60)
            }
        }
        .frame(maxWidth: 820)
        .frame(maxWidth: .infinity, alignment: .center)
    }

    private var bubble: some View {
        VStack(alignment: .leading, spacing: 5) {
            if entry.kind == .specialist || entry.kind == .activity {
                Text(entry.kind == .activity ? "SQUAD" : (entry.modelID ?? "SPECIALIST").uppercased())
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .tracking(0.8)
                    .foregroundStyle(entry.kind == .activity ? Color.secondary : Color(red: 0.51, green: 0.35, blue: 0.40))
            }
            if isCanvasText {
                ScrollView(.horizontal, showsIndicators: true) {
                    Text(entry.text)
                        .font(.system(size: 10, design: .monospaced))
                        .foregroundStyle(entry.kind == .activity ? Color.secondary : Color.primary)
                        .textSelection(.enabled)
                        .fixedSize(horizontal: true, vertical: true)
                }
            } else {
                Text(entry.text)
                    .font(.system(size: entry.kind == .activity ? 10 : 12))
                    .foregroundStyle(entry.kind == .activity ? Color.secondary : Color.primary)
                    .textSelection(.enabled)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if let sequence = TempleOSMusicSequence.parse(entry.text) {
                TempleOSMusicPlaybackButton(sequence: sequence)
                    .padding(.top, 3)
            }
        }
        .padding(entry.kind == .activity ? 7 : 11)
        .background(background, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
        .frame(maxWidth: 600, alignment: .leading)
    }

    private var isCanvasText: Bool {
        entry.modelID?.lowercased() == "tool:ascii_canvas" || entry.text.hasPrefix("ASCII canvas ·")
    }

    private var background: Color {
        switch entry.kind {
        case .user: Color(red: 0.91, green: 0.85, blue: 0.86)
        case .assistant: .white
        case .specialist: Color(red: 0.96, green: 0.94, blue: 0.91)
        case .activity: .clear
        }
    }
}

private struct ConversationSidebarView: View {
    @EnvironmentObject private var state: OrbitAppState
    @Binding var showConversationManager: Bool
    @Binding var showTempleOSPoly: Bool
    @Binding var showTempleOSElephant: Bool
    @Binding var showTempleOSBSpline: Bool

    private let modelColumns = [GridItem(.flexible(), spacing: 6), GridItem(.flexible(), spacing: 6)]
    private let toolColumns = [GridItem(.flexible(), spacing: 6), GridItem(.flexible(), spacing: 6)]
    private let tools = [
        ToolShortcut(title: "Calculator", symbol: "calculator", starter: "Use the calculator to evaluate: "),
        ToolShortcut(title: "Scientific", symbol: "function", starter: "Use the scientific calculator to evaluate: "),
        ToolShortcut(title: "ASCII canvas", symbol: "textformat", starter: "Use the ASCII canvas to draw: "),
        ToolShortcut(title: "Music notes", symbol: "music.note.list", starter: "Compose a short melody with TempleOS music notes: ")
    ]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 13) {
                brandAndMenu
                newConversationButton
                coordinatorPicker
                sectionLabel("MODELS")
                if state.models.isEmpty {
                    Text("No compatible local models found")
                        .font(.system(size: 9))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                } else {
                    LazyVGrid(columns: modelColumns, spacing: 10) {
                        ForEach(Array(state.models.enumerated()), id: \.element.id) { index, model in
                            ModelShortcutTile(model: model, index: index, count: state.models.count)
                                .environmentObject(state)
                        }
                    }
                }
                sectionLabel("TOOLS")
                LazyVGrid(columns: toolColumns, spacing: 8) {
                    ForEach(tools) { tool in
                        Button {
                            state.prompt = tool.starter
                        } label: {
                            VStack(spacing: 5) {
                                Image(systemName: tool.symbol)
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                                    .frame(width: 32, height: 32)
                                    .background(.white, in: Circle())
                                    .overlay(Circle().stroke(Color.black.opacity(0.08), lineWidth: 1))
                                Text(tool.title)
                                    .font(.system(size: 8, weight: .medium))
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.75)
                                    .foregroundStyle(.primary)
                            }
                            .frame(maxWidth: .infinity)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .disabled(state.isBusy)
                        .help("Insert a prompt starter for the \(tool.title) tool")
                    }
                }
                sectionLabel("TEMPLEOS")
                LazyVGrid(columns: toolColumns, spacing: 8) {
                    demoShortcut(title: "3D Poly", symbol: "cube.transparent") { showTempleOSPoly = true }
                    demoShortcut(title: "Elephant", symbol: "hare") { showTempleOSElephant = true }
                    demoShortcut(title: "B-spline", symbol: "scribble.variable") { showTempleOSBSpline = true }
                    Button { state.generateGodWord() } label: {
                        VStack(spacing: 5) {
                            Image(systemName: "sparkles")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                                .frame(width: 32, height: 32)
                                .background(.white, in: Circle())
                                .overlay(Circle().stroke(Color.black.opacity(0.08), lineWidth: 1))
                            Text("God word")
                                .font(.system(size: 8, weight: .medium))
                                .foregroundStyle(.primary)
                        }
                        .frame(maxWidth: .infinity)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .disabled(state.isBusy)
                    .help("Explicitly generate one God word locally; the model cannot call this tool")
                }
                Spacer(minLength: 12)
                thinkingStatus
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 12)
        }
        .background(Color(red: 0.955, green: 0.938, blue: 0.916))
    }

    private func demoShortcut(title: String, symbol: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 5) {
                Image(systemName: symbol)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                    .frame(width: 32, height: 32)
                    .background(.white, in: Circle())
                    .overlay(Circle().stroke(Color.black.opacity(0.08), lineWidth: 1))
                Text(title)
                    .font(.system(size: 8, weight: .medium))
                    .foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .help("Open the \(title) TempleOS-inspired demo")
    }

    private var brandAndMenu: some View {
        HStack(spacing: 8) {
            Menu {
                Button("New conversation", systemImage: "square.and.pencil") { state.startNewConversation() }
                    .disabled(state.isBusy)
                Button("Conversation manager…", systemImage: "tray.full") { showConversationManager = true }
                Divider()
                Button("3D Poly demo", systemImage: "cube.transparent") { showTempleOSPoly = true }
                Button("Elephant demo", systemImage: "hare") { showTempleOSElephant = true }
                Button("B-spline demo", systemImage: "scribble.variable") { showTempleOSBSpline = true }
                    Button("Generate God word", systemImage: "sparkles") { state.generateGodWord() }
                if !state.activeConversations.isEmpty { Divider() }
                ForEach(state.activeConversations) { conversation in
                    Button {
                        state.openConversation(conversation)
                    } label: {
                        if conversation.isPinned {
                            Label(conversation.title, systemImage: "pin.fill")
                        } else {
                            Text(conversation.title)
                        }
                    }
                    .disabled(state.isBusy)
                }
            } label: {
                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 12, weight: .medium))
                    .frame(width: 28, height: 28)
                    .background(.white.opacity(0.9), in: Circle())
                    .overlay(Circle().stroke(Color.black.opacity(0.08), lineWidth: 1))
            }
            .menuStyle(.borderlessButton)
            .help("Conversation menu")

            VStack(alignment: .leading, spacing: 1) {
                Text("ORBIT")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .tracking(1.8)
                Text("LOCAL MODEL SQUAD")
                    .font(.system(size: 7, weight: .medium, design: .monospaced))
                    .tracking(0.5)
                    .foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
    }

    private var newConversationButton: some View {
        Button { state.startNewConversation() } label: {
            Label("New chat", systemImage: "square.and.pencil")
                .font(.system(size: 10, weight: .medium))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 9)
                .frame(height: 31)
                .background(.white.opacity(0.82), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(Color.black.opacity(0.07), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .disabled(state.isBusy)
        .help(state.isBusy ? "Wait for the current response to finish before starting a new chat" : "Start a new chat")
    }

    private var coordinatorPicker: some View {
        Menu {
            ForEach(state.models) { model in
                Button {
                    state.setMainModel(model)
                } label: {
                    if model.id == state.mainModelID {
                        Label(state.appearance(for: model).shortDescription, systemImage: "checkmark")
                    } else {
                        Text(state.appearance(for: model).shortDescription)
                    }
                }
            }
        } label: {
            HStack(spacing: 7) {
                Image(systemName: "circle.hexagongrid.fill")
                    .font(.system(size: 13))
                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                VStack(alignment: .leading, spacing: 2) {
                    Text("COORDINATOR")
                        .font(.system(size: 7, weight: .bold, design: .monospaced))
                        .tracking(0.5)
                    Text(state.mainModel.map { state.appearance(for: $0).shortDescription } ?? "Choose a model")
                        .font(.system(size: 9, weight: .medium))
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.down")
                    .font(.system(size: 8, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 8)
            .frame(height: 40)
            .background(.white, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(Color(red: 0.78, green: 0.65, blue: 0.68), lineWidth: 1))
        }
        .menuStyle(.borderlessButton)
        .disabled(state.models.isEmpty || state.isBusy)
        .help("Choose which local model coordinates squad work")
    }

    private func sectionLabel(_ title: String) -> some View {
        HStack(spacing: 6) {
            Text(title)
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .tracking(0.9)
                .foregroundStyle(.secondary)
            Rectangle().fill(Color.black.opacity(0.08)).frame(height: 1)
        }
        .padding(.top, 2)
    }

    private var thinkingStatus: some View {
        HStack(alignment: .center, spacing: 7) {
            assistantAvatarImage
                .frame(width: 44, height: 59)
                .clipShape(RoundedRectangle(cornerRadius: 7, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 7, style: .continuous).stroke(Color.black.opacity(0.12), lineWidth: 1))
                .accessibilityLabel("Orbit virtual assistant")
            VStack(alignment: .leading, spacing: 4) {
                Text(state.isBusy ? "Orbit is thinking…" : "Orbit is ready")
                    .font(.system(size: 8, weight: .semibold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                Text(statusDetail)
                    .font(.system(size: 7, weight: .medium, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                if state.isBusy {
                    BundledImageView(resource: "thinking-dots", fileExtension: "gif", animates: true)
                        .frame(width: 78, height: 58)
                        .clipShape(RoundedRectangle(cornerRadius: 5, style: .continuous))
                        .accessibilityLabel("Orbit is thinking")
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.top, 8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .overlay(alignment: .top) { Rectangle().fill(Color.black.opacity(0.08)).frame(height: 1) }
    }

    @ViewBuilder private var assistantAvatarImage: some View {
        if let resourceURL = Bundle.main.resourceURL?.appendingPathComponent("assistant-avatar.png"),
           let image = NSImage(contentsOf: resourceURL) {
            Image(nsImage: image)
                .resizable()
                .scaledToFit()
        } else {
            Rectangle()
                .fill(.black)
                .overlay(Image(systemName: "person.fill").font(.system(size: 18)).foregroundStyle(.white))
        }
    }

    private var statusDetail: String {
        guard state.isBusy else { return "\(state.models.count) LOCAL MODELS" }
        guard let model = state.models.first(where: { $0.id == state.activeModelID }) else { return "LOCAL INFERENCE" }
        return state.appearance(for: model).shortDescription.uppercased()
    }
}

private struct ModelShortcutTile: View {
    @EnvironmentObject private var state: OrbitAppState
    let model: LocalModel
    let index: Int
    let count: Int

    var body: some View {
        TimelineView(.animation(minimumInterval: 1 / 30, paused: !state.isBusy)) { timeline in
            let appearance = state.appearance(for: model)
            let time = timeline.date.timeIntervalSinceReferenceDate
            let pulse = highlight(time: time)
            Button {
                state.useDirectModel(model)
            } label: {
                VStack(spacing: 4) {
                    modelIcon(appearance)
                        .frame(width: 34, height: 34)
                        .background(.white, in: Circle())
                        .overlay(Circle().stroke(Color(red: 0.65, green: 0.45, blue: 0.51).opacity(0.12 + pulse * 0.8), lineWidth: model.id == state.mainModelID || model.id == state.activeModelID ? 1.5 : 1))
                        .shadow(color: Color(red: 0.65, green: 0.45, blue: 0.51).opacity(pulse * 0.4), radius: 8 * pulse)
                    Text(appearance.shortDescription)
                        .font(.system(size: 7, weight: model.id == state.mainModelID ? .semibold : .medium))
                        .lineLimit(2)
                        .multilineTextAlignment(.center)
                        .minimumScaleFactor(0.72)
                        .frame(height: 19, alignment: .top)
                        .foregroundStyle(.primary)
                }
                .frame(maxWidth: .infinity, minHeight: 58)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .disabled(state.isBusy)
            .help("Use \(appearance.shortDescription) directly. Right-click to set it as coordinator.")
            .accessibilityLabel("\(appearance.shortDescription), local model")
            .contextMenu {
                Button("Make coordinator") { state.setMainModel(model) }
                Button("Use directly") { state.useDirectModel(model) }
            }
        }
    }

    private func highlight(time: Double) -> Double {
        guard state.isBusy else { return model.id == state.mainModelID ? 0.14 : 0 }
        if state.coordinatorIsThinking && model.id == state.mainModelID {
            return OrbitMotion.coordinatorPulse(index: index, count: count, time: time)
        }
        if model.id == state.activeModelID {
            return OrbitMotion.breathingPulse(time: time, phase: Double(index) * 0.42)
        }
        return 0
    }

    @ViewBuilder private func modelIcon(_ appearance: ModelAppearance) -> some View {
        if let path = appearance.customImagePath, let image = NSImage(contentsOfFile: path) {
            Image(nsImage: image).resizable().scaledToFill().clipShape(Circle())
        } else {
            Image(systemName: appearance.symbolName)
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
        }
    }
}

private struct ToolShortcut: Identifiable {
    let title: String
    let symbol: String
    let starter: String
    var id: String { title }
}

private struct ConversationUtilityRail: View {
    @EnvironmentObject private var state: OrbitAppState
    @Binding var showTaskManager: Bool
    let onAddModel: () -> Void
    let onRefreshModels: () -> Void
    let onAddFile: () -> Void
    let onInspectHex: (PreparedAttachment) -> Void

    @State private var showExporter = false
    @State private var exportDocument = ConversationArchiveDocument(text: "")
    @State private var exportFilename = "Orbit attachment text"
    @StateObject private var resourceUsageMonitor = ResourceUsageMonitor()

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 12) {
                readinessPanel
                Rectangle().fill(Color.black.opacity(0.1)).frame(height: 1)
                fileContextPanel
                Spacer(minLength: 8)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 12)
        }
        .background(Color(red: 0.955, green: 0.938, blue: 0.916))
        .fileExporter(
            isPresented: $showExporter,
            document: exportDocument,
            contentType: .plainText,
            defaultFilename: exportFilename
        ) { result in
            if case .failure(let error) = result { state.errorMessage = error.localizedDescription }
        }
    }

    private var readinessPanel: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("READINESS")
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .tracking(0.9)
                .foregroundStyle(.secondary)
            providerRow(title: "LOCAL", detail: localStatusDetail, color: localStatusColor, isConfigured: true)
            resourceUsagePanel
            if !state.tasks.isEmpty { taskSummary }
            providerRow(title: "NET", detail: "Not configured", color: Color.gray.opacity(0.55), isConfigured: false)
            providerRow(title: "CLOUD", detail: "Not configured", color: Color.gray.opacity(0.55), isConfigured: false)
        }
    }

    private func providerRow(title: String, detail: String, color: Color, isConfigured: Bool) -> some View {
        HStack(spacing: 5) {
            Circle().fill(color).frame(width: 6, height: 6)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .tracking(0.6)
                Text(detail)
                    .font(.system(size: 7, weight: .medium))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            Spacer(minLength: 0)
            Button(action: isConfigured ? onAddModel : {}) {
                Image(systemName: "plus")
                    .font(.system(size: 8, weight: .semibold))
                    .frame(width: 19, height: 19)
                    .background(.white, in: Circle())
            }
            .buttonStyle(.plain)
            .disabled(!isConfigured || state.isBusy)
            .help(isConfigured ? "Download a local model" : "No network provider is configured")
            Button(action: isConfigured ? onRefreshModels : {}) {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 8, weight: .semibold))
                    .frame(width: 19, height: 19)
                    .background(.white, in: Circle())
            }
            .buttonStyle(.plain)
            .disabled(!isConfigured || state.isBusy)
            .help(isConfigured ? "Refresh local model discovery" : "No provider is configured")
        }
        .padding(.horizontal, 7)
        .padding(.vertical, 6)
        .background(.white.opacity(0.84), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
    }

    private var localStatusDetail: String {
        state.connectionStatus
            .replacingOccurrences(of: "LOCAL · ", with: "")
            .replacingOccurrences(of: "LOCAL ", with: "")
            .lowercased()
    }

    private var localStatusColor: Color {
        if state.connectionStatus.contains("SCANNING") { return Color(red: 0.75, green: 0.56, blue: 0.28) }
        if state.connectionStatus.contains("NO ") || state.connectionStatus.contains("0 READY") { return .orange }
        return Color(red: 0.36, green: 0.59, blue: 0.47)
    }

    private var resourceUsagePanel: some View {
        let sample = resourceUsageMonitor.snapshot
        let gpuValue: String
        if let allocated = sample.metalAllocatedBytes {
            let workingSet = sample.metalWorkingSetBytes.map { " / \(formatGiB($0))" } ?? ""
            gpuValue = "\(formatGiB(allocated))\(workingSet) GiB"
        } else {
            gpuValue = "unavailable"
        }
        return VStack(alignment: .leading, spacing: 5) {
            Text("RESOURCE USE")
                .font(.system(size: 7, weight: .bold, design: .monospaced))
                .tracking(0.7)
                .foregroundStyle(.secondary)
            resourceMetric("APP CPU", value: sample.appCPUPercent.map { String(format: "%.0f%%", $0) } ?? "sampling")
            resourceMetric("APP RAM", value: "\(formatGiB(sample.appPhysicalBytes)) / \(formatGiB(sample.totalPhysicalBytes)) GiB")
            resourceMetric("GPU MEM", value: gpuValue)
            Text("GPU utilization % unavailable")
                .font(.system(size: 7, weight: .medium))
                .foregroundStyle(.tertiary)
        }
        .padding(8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.white.opacity(0.72), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .help("CPU is Orbit's share of total CPU capacity. RAM is Orbit's physical footprint versus installed memory. GPU shows Orbit's Metal allocation and recommended working-set size; public macOS APIs do not expose GPU utilization percent.")
    }

    private func resourceMetric(_ label: String, value: String) -> some View {
        HStack(spacing: 4) {
            Text(label)
                .font(.system(size: 7, weight: .semibold, design: .monospaced))
                .foregroundStyle(.secondary)
            Spacer(minLength: 0)
            Text(value)
                .font(.system(size: 7, weight: .medium, design: .monospaced))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
    }

    private func formatGiB(_ bytes: UInt64?) -> String {
        guard let bytes else { return "—" }
        return String(format: "%.1f", Double(bytes) / 1_073_741_824)
    }

    private var taskSummary: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Tasks: \(state.tasks.count), completed \(state.completedTaskCount)")
                .font(.system(size: 8, weight: .semibold, design: .monospaced))
                .fixedSize(horizontal: false, vertical: true)
            Button { showTaskManager = true } label: {
                HStack(spacing: 4) {
                    Text("See more")
                    Image(systemName: "arrow.right")
                }
                .font(.system(size: 8, weight: .medium))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("See more task details")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(8)
        .background(Color(red: 0.93, green: 0.87, blue: 0.88).opacity(0.55), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
    }

    private var fileContextPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("FILE CONTEXT")
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .tracking(0.8)
                Spacer()
                Button(action: onAddFile) {
                    Image(systemName: "plus")
                        .font(.system(size: 9, weight: .semibold))
                        .frame(width: 20, height: 20)
                        .background(.white, in: Circle())
                }
                .buttonStyle(.plain)
                .help("Attach a file to this conversation")
            }
            if let attachment = state.attachmentForPanel {
                attachmentCard(attachment)
            } else if let name = recentAttachmentName {
                historicalAttachmentCard(name: name)
            } else {
                VStack(alignment: .leading, spacing: 7) {
                    Image(systemName: "doc.badge.plus")
                        .font(.system(size: 19, weight: .regular))
                        .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                    Text("No file selected")
                        .font(.system(size: 9, weight: .semibold))
                    Text("Attach a document, image, PDF, or binary file to keep it beside the conversation.")
                        .font(.system(size: 8))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    Button("Add file", action: onAddFile)
                        .font(.system(size: 8, weight: .semibold))
                        .buttonStyle(.plain)
                        .padding(.top, 2)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(10)
                .background(.white.opacity(0.84), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(Color.black.opacity(0.07), lineWidth: 1))
            }
        }
    }

    private func attachmentCard(_ attachment: PreparedAttachment) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 7) {
                Image(systemName: icon(for: attachment.kind))
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                    .frame(width: 27, height: 30)
                    .background(Color(red: 0.973, green: 0.961, blue: 0.945), in: RoundedRectangle(cornerRadius: 7))
                VStack(alignment: .leading, spacing: 3) {
                    Text(attachment.name)
                        .font(.system(size: 9, weight: .semibold))
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("\(ByteCountFormatter.string(fromByteCount: Int64(attachment.byteCount), countStyle: .file)) · \(attachment.kind.rawValue.uppercased())")
                        .font(.system(size: 7, weight: .medium, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                }
            }
            Text(attachment.text.isEmpty ? attachment.summary : attachment.text)
                .font(.system(size: 8))
                .foregroundStyle(.secondary)
                .lineLimit(5)
                .textSelection(.enabled)
            HStack(spacing: 4) {
                fileAction(title: "Save as", symbol: "square.and.arrow.down") { saveText(attachment) }
                fileAction(title: "Copy", symbol: "doc.on.doc") { copyText(attachment) }
                fileAction(title: "Send to", symbol: "arrow.up.right") { sendAttachment(attachment) }
            }
            if attachment.kind == .hex {
                Button("Inspect hex") { onInspectHex(attachment) }
                    .font(.system(size: 8, weight: .medium))
                    .buttonStyle(.plain)
            }
        }
        .padding(9)
        .background(.white, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(Color.black.opacity(0.07), lineWidth: 1))
    }

    private func historicalAttachmentCard(name: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 7) {
                Image(systemName: "doc.text")
                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                Text(name)
                    .font(.system(size: 9, weight: .semibold))
                    .lineLimit(2)
            }
            Text("Referenced earlier in this conversation. Reattach it to inspect or export its contents.")
                .font(.system(size: 8))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Button("Reattach file", action: onAddFile)
                .font(.system(size: 8, weight: .medium))
                .buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(9)
        .background(.white, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private var recentAttachmentName: String? {
        for entry in state.messages.reversed() where entry.kind == .user {
            guard let marker = entry.text.range(of: "Attached: ") else { continue }
            return String(entry.text[marker.upperBound...]).components(separatedBy: ",").first?.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return nil
    }

    private func fileAction(title: String, symbol: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: symbol).font(.system(size: 10, weight: .medium))
                Text(title).font(.system(size: 7, weight: .medium)).lineLimit(1).minimumScaleFactor(0.7)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 36)
            .background(Color(red: 0.973, green: 0.961, blue: 0.945), in: RoundedRectangle(cornerRadius: 7, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private func saveText(_ attachment: PreparedAttachment) {
        let contents = attachment.text.isEmpty ? attachment.summary : attachment.text
        exportDocument = ConversationArchiveDocument(text: "Attachment: \(attachment.name)\n\n\(contents)")
        exportFilename = URL(fileURLWithPath: attachment.name).deletingPathExtension().lastPathComponent + " extracted text"
        showExporter = true
    }

    private func copyText(_ attachment: PreparedAttachment) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(attachment.text.isEmpty ? attachment.summary : attachment.text, forType: .string)
    }

    private func sendAttachment(_ attachment: PreparedAttachment) {
        if state.pendingAttachments.contains(where: { $0.id == attachment.id }) {
            state.send()
        } else {
            state.stageAttachmentForResend(attachment)
        }
    }

    private func icon(for kind: AttachmentKind) -> String {
        switch kind {
        case .text: "doc.text"
        case .image: "photo"
        case .pdf: "doc.richtext"
        case .hex: "number"
        case .other: "doc"
        }
    }
}

private struct BundledImageView: NSViewRepresentable {
    let resource: String
    let fileExtension: String
    let animates: Bool

    func makeNSView(context: Context) -> NSImageView {
        let view = NSImageView(frame: .zero)
        view.imageScaling = .scaleProportionallyUpOrDown
        view.image = loadImage()
        view.animates = animates
        return view
    }

    func updateNSView(_ view: NSImageView, context: Context) {
        if view.image == nil { view.image = loadImage() }
        view.animates = animates
    }

    private func loadImage() -> NSImage? {
        guard let url = Bundle.main.resourceURL?.appendingPathComponent("\(resource).\(fileExtension)") else { return nil }
        return NSImage(contentsOf: url)
    }
}


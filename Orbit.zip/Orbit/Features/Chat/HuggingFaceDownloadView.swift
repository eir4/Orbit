import SwiftUI
import OrbitCore

struct HuggingFaceDownloadView: View {
    @EnvironmentObject private var state: OrbitAppState
    @Environment(\.dismiss) private var dismiss
    @State private var repoID = ""
    @State private var progress = 0.0
    @State private var transferSpeed: Double?
    @State private var isDownloading = false
    @State private var errorMessage: String?
    @State private var downloadTask: Task<Void, Never>?

    private var isValidRepoID: Bool { (try? HuggingFaceRepoID(repoID)) != nil }

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack(spacing: 10) {
                Image(systemName: "arrow.down.circle")
                    .font(.system(size: 24, weight: .regular))
                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                VStack(alignment: .leading, spacing: 3) {
                    Text("Add a model")
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                    Text("FROM HUGGING FACE")
                        .font(.system(size: 8, weight: .medium, design: .monospaced))
                        .tracking(1.1)
                        .foregroundStyle(.secondary)
                }
            }

            TextField("owner/model-repository", text: $repoID)
                .textFieldStyle(.roundedBorder)
                .disabled(isDownloading)

            VStack(alignment: .leading, spacing: 5) {
                Text("Downloads to ~/LocalAI. Orbit lists recognized generative MLX bundles with tokenizer metadata and safetensors/NPZ weights; GGUF and image-generation-only models are not loadable yet.")
                Text("Public models need no sign-in. For gated models, Orbit uses your existing Hugging Face CLI login or HF_TOKEN environment setting.")
            }
            .font(.system(size: 10))
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)

            if isDownloading {
                VStack(alignment: .leading, spacing: 6) {
                    ProgressView(value: progress)
                    HStack {
                        Text("Downloading · \(Int(progress * 100))%")
                        Spacer()
                        if let transferSpeed, transferSpeed > 0 {
                            Text(speedDescription(transferSpeed))
                        }
                    }
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundStyle(.secondary)
                }
            }

            if let errorMessage {
                Text(errorMessage)
                    .font(.system(size: 10))
                    .foregroundStyle(.red)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack {
                Button("Cancel") {
                    downloadTask?.cancel()
                    dismiss()
                }
                .keyboardShortcut(.cancelAction)
                Spacer()
                Button(isDownloading ? "Downloading…" : "Download") { startDownload() }
                    .keyboardShortcut(.defaultAction)
                    .disabled(isDownloading || !isValidRepoID)
            }
        }
        .padding(20)
        .frame(width: 430)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
        .onDisappear { downloadTask?.cancel() }
    }

    private func startDownload() {
        guard !isDownloading, let repo = try? HuggingFaceRepoID(repoID) else { return }
        errorMessage = nil
        progress = 0
        transferSpeed = nil
        isDownloading = true
        let identifier = repo.value
        let downloader = HuggingFaceModelDownloader()
        downloadTask = Task { @MainActor in
            do {
                let snapshot = try await downloader.download(repoID: identifier) { fraction, speed in
                    Task { @MainActor in
                        progress = fraction
                        transferSpeed = speed
                    }
                }
                await state.refreshModels()
                let repoPath = "/models/\(identifier.lowercased())"
                let loaded = state.models.contains { $0.id.lowercased().contains(repoPath) }
                isDownloading = false
                if !loaded {
                    errorMessage = "Download finished, but Orbit did not find a selectable chat bundle in this snapshot. It may be an unsupported GGUF/image model or exceed the safe memory budget. Snapshot saved at: \(snapshot.path)"
                    return
                }
                dismiss()
            } catch is CancellationError {
                isDownloading = false
            } catch {
                isDownloading = false
                errorMessage = error.localizedDescription
            }
        }
    }

    private func speedDescription(_ bytesPerSecond: Double) -> String {
        String(format: "%.1f MiB/s", bytesPerSecond / 1_048_576)
    }
}

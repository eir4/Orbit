import SwiftUI
import UniformTypeIdentifiers
import OrbitCore

struct ConversationManagerView: View {
    @EnvironmentObject private var state: OrbitAppState
    @Environment(\.dismiss) private var dismiss
    @State private var showImporter = false
    @State private var showExporter = false
    @State private var exportDocument = ConversationArchiveDocument(text: "")
    @State private var exportFilename = "Orbit conversation"
    @State private var exportConversationID: UUID?
    @State private var deleteTarget: ConversationRecord?
    @State private var showDeleteConfirmation = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(spacing: 0) {
            header
            List {
                if !state.activeConversations.filter(\.isPinned).isEmpty {
                    Section("Pinned") {
                        ForEach(state.activeConversations.filter(\.isPinned)) { conversation in
                            conversationRow(conversation, archived: false)
                        }
                    }
                }
                Section("Conversations") {
                    if state.activeConversations.filter({ !$0.isPinned }).isEmpty {
                        Text("No unpinned conversations")
                            .font(.system(size: 11))
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(state.activeConversations.filter { !$0.isPinned }) { conversation in
                            conversationRow(conversation, archived: false)
                        }
                    }
                }
                Section("Archived") {
                    if state.archivedConversations.isEmpty {
                        Text("Archived conversations appear here")
                            .font(.system(size: 11))
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(state.archivedConversations) { conversation in
                            conversationRow(conversation, archived: true)
                        }
                    }
                }
            }
            .listStyle(.inset)
        }
        .frame(minWidth: 720, minHeight: 500)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
        .fileExporter(
            isPresented: $showExporter,
            document: exportDocument,
            contentType: .plainText,
            defaultFilename: exportFilename
        ) { result in
            switch result {
            case .success:
                if let exportConversationID { state.archiveConversation(exportConversationID) }
            case .failure(let error):
                errorMessage = error.localizedDescription
            }
            exportConversationID = nil
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.plainText], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                importArchive(from: url)
            case .failure(let error):
                errorMessage = error.localizedDescription
            }
        }
        .confirmationDialog(
            "Delete this conversation permanently?",
            isPresented: $showDeleteConfirmation,
            titleVisibility: .visible
        ) {
            Button("Delete Conversation", role: .destructive) {
                if let deleteTarget { state.deleteConversation(deleteTarget.id) }
                deleteTarget = nil
            }
            Button("Cancel", role: .cancel) { deleteTarget = nil }
        } message: {
            Text("This removes the conversation from Orbit and cannot be undone.")
        }
        .alert("Conversation Manager", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Conversation manager")
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                Text("PIN, ARCHIVE, RESTORE, OR REMOVE A CONVERSATION")
                    .font(.system(size: 8, weight: .medium, design: .monospaced))
                    .tracking(0.8)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button {
                showImporter = true
            } label: {
                Label("Unarchive .txt…", systemImage: "tray.and.arrow.down")
            }
            .disabled(state.isBusy)
            Button("Done") { dismiss() }
                .keyboardShortcut(.cancelAction)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
    }

    private func conversationRow(_ conversation: ConversationRecord, archived: Bool) -> some View {
        HStack(spacing: 12) {
            Button {
                if archived {
                    state.unarchiveConversation(conversation.id)
                } else {
                    state.openConversation(conversation)
                    dismiss()
                }
            } label: {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 6) {
                        if conversation.isPinned {
                            Image(systemName: "pin.fill")
                                .font(.system(size: 9))
                                .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                        }
                        Text(conversation.title)
                            .font(.system(size: 12, weight: .medium))
                            .lineLimit(1)
                    }
                    Text("\(conversation.entries.count) entries · \(conversation.updatedAt.formatted(date: .abbreviated, time: .shortened))")
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .disabled(state.isBusy)
            .help(archived ? "Unarchive this conversation" : "Open this conversation")

            if archived {
                Button {
                    state.unarchiveConversation(conversation.id)
                } label: {
                    Image(systemName: "tray.and.arrow.up")
                }
                .help("Unarchive")
            } else {
                Button {
                    state.setPinned(!conversation.isPinned, for: conversation.id)
                } label: {
                    Image(systemName: conversation.isPinned ? "pin.slash" : "pin")
                }
                .help(conversation.isPinned ? "Unpin conversation" : "Pin conversation to the top")
                .disabled(state.isBusy)

                Button {
                    prepareArchive(conversation)
                } label: {
                    Image(systemName: "archivebox")
                }
                .help("Save as a text archive and archive this conversation")
                .disabled(state.isBusy)
            }

            Button(role: .destructive) {
                deleteTarget = conversation
                showDeleteConfirmation = true
            } label: {
                Image(systemName: "trash")
            }
            .help("Delete conversation")
            .disabled(state.isBusy)
        }
        .padding(.vertical, 4)
    }

    private func prepareArchive(_ conversation: ConversationRecord) {
        do {
            let text = try ConversationArchiveCodec.encode(conversation)
            exportDocument = ConversationArchiveDocument(text: text)
            exportFilename = safeFilename(conversation.title)
            exportConversationID = conversation.id
            showExporter = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func importArchive(from url: URL) {
        let hasAccess = url.startAccessingSecurityScopedResource()
        defer { if hasAccess { url.stopAccessingSecurityScopedResource() } }
        do {
            let text = try String(contentsOf: url, encoding: .utf8)
            try state.importArchivedText(text)
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func safeFilename(_ title: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: " -_"))
        let safe = String(title.unicodeScalars.map { allowed.contains($0) ? Character($0) : "-" })
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return safe.isEmpty ? "Orbit conversation" : safe
    }
}

struct ConversationArchiveDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.plainText] }
    var text: String

    init(text: String) { self.text = text }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents,
              let value = String(data: data, encoding: .utf8) else {
            throw CocoaError(.fileReadCorruptFile)
        }
        text = value
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: Data(text.utf8))
    }
}

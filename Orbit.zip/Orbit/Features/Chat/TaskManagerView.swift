import SwiftUI
import OrbitCore

struct TaskManagerView: View {
    @EnvironmentObject private var state: OrbitAppState
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Tasks")
                        .font(.system(size: 18, weight: .semibold, design: .rounded))
                    Text("\(state.completedTaskCount) completed · \(state.tasks.count - state.completedTaskCount) remaining")
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button("Done") { dismiss() }
                    .keyboardShortcut(.cancelAction)
            }
            .padding(18)

            if state.tasks.isEmpty {
                Spacer()
                Text("No multi-step tasks for this response.")
                    .font(.system(size: 12))
                    .foregroundStyle(.secondary)
                Spacer()
            } else {
                TimelineView(.periodic(from: .now, by: 1)) { timeline in
                    ScrollView {
                        LazyVStack(spacing: 9) {
                            ForEach(state.tasks) { task in
                                TaskProgressRow(task: task, now: timeline.date)
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)
                    }
                }
            }
        }
        .frame(width: 620, height: 480)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
    }
}

private struct TaskProgressRow: View {
    let task: OrbitTask
    let now: Date

    private var progress: Int { task.progressEstimate(at: now) }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(iconColor)
                    .frame(width: 20)
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 7) {
                        if task.status == .inProgress {
                            Text("CURRENT")
                                .font(.system(size: 8, weight: .bold, design: .monospaced))
                                .tracking(0.6)
                                .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                        }
                        Text(task.title)
                            .font(.system(size: 11, weight: .medium))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    if let modelID = task.modelID {
                        Text(modelID)
                            .font(.system(size: 8, design: .monospaced))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }
                Spacer(minLength: 10)
                Text("\(progress)%")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .monospacedDigit()
            }
            ProgressView(value: Double(progress), total: 100)
                .tint(task.status == .completed ? Color(red: 0.32, green: 0.55, blue: 0.40) : Color(red: 0.51, green: 0.35, blue: 0.40))
                .padding(.leading, 30)
        }
        .padding(12)
        .background(.white.opacity(0.85), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.black.opacity(0.07), lineWidth: 1))
    }

    private var icon: String {
        switch task.status {
        case .pending: "circle"
        case .inProgress: "arrow.triangle.2.circlepath"
        case .completed: "checkmark.circle.fill"
        }
    }

    private var iconColor: Color {
        task.status == .completed ? Color(red: 0.32, green: 0.55, blue: 0.40) : Color(red: 0.51, green: 0.35, blue: 0.40)
    }
}

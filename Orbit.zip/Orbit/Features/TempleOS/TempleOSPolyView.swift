import SwiftUI

struct TempleOSPolyView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var isAnimating = true
    @State private var committedRotation = CGSize.zero
    @GestureState private var dragOffset = CGSize.zero

    private let profile: [(Double, Double)] = [(-125, -70), (125, -95), (35, 105), (-55, 95)]

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "cube.transparent")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(Color(red: 0.46, green: 0.82, blue: 0.69))
                VStack(alignment: .leading, spacing: 3) {
                    Text("3D POLY")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(1.2)
                    Text("TempleOS-inspired rotating polygon")
                        .font(.system(size: 10))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button(isAnimating ? "Pause" : "Spin") { isAnimating.toggle() }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                Button("Reset") { committedRotation = .zero }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                Button("Done") { dismiss() }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
            }
            .padding(16)

            TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !isAnimating)) { timeline in
                Canvas { context, size in
                    let time = timeline.date.timeIntervalSinceReferenceDate
                    let yaw = Double(committedRotation.width + dragOffset.width) * 0.01 + (isAnimating ? time * 0.35 : 0)
                    let pitch = 0.28 + Double(committedRotation.height + dragOffset.height) * 0.01
                    let faces = makeFaces()
                    let projectedFaces = faces.map { face in
                        let points = face.vertices.map { project($0, yaw: yaw, pitch: pitch, roll: time * 0.19, size: size) }
                        return ProjectedFace(points: points.map(\.point), depth: points.map(\.depth).reduce(0, +) / Double(points.count), color: face.color)
                    }.sorted { $0.depth < $1.depth }

                    for face in projectedFaces {
                        guard let first = face.points.first else { continue }
                        var path = Path()
                        path.move(to: first)
                        for point in face.points.dropFirst() { path.addLine(to: point) }
                        path.closeSubpath()
                        context.fill(path, with: .color(face.color.opacity(0.78)))
                        context.stroke(path, with: .color(.white.opacity(0.62)), lineWidth: 1.1)
                    }
                }
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 2)
                        .updating($dragOffset) { value, state, _ in state = value.translation }
                        .onEnded { value in
                            committedRotation.width += value.translation.width
                            committedRotation.height += value.translation.height
                        }
                )
            }
            .background(Color(red: 0.075, green: 0.09, blue: 0.12))
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .padding(.horizontal, 16)

            HStack(spacing: 16) {
                Label("Drag to rotate", systemImage: "hand.draw")
                Text("Three colored polygon planes with depth faces")
            }
            .font(.system(size: 10, design: .monospaced))
            .foregroundStyle(.secondary)
            .padding(14)
        }
        .padding(8)
        .frame(minWidth: 620, minHeight: 470)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
    }

    private func makeFaces() -> [PolyFace] {
        let rear = profile.map { PolyVertex(x: $0.0, y: $0.1, z: -50) }
        let middle = profile.map { PolyVertex(x: $0.0, y: $0.1, z: 0) }
        let front = profile.map { PolyVertex(x: $0.0, y: $0.1, z: 50) }
        return [
            PolyFace(vertices: rear, color: Color(red: 0.24, green: 0.48, blue: 0.92)),
            PolyFace(vertices: middle, color: Color(red: 0.25, green: 0.78, blue: 0.48)),
            PolyFace(vertices: front, color: Color(red: 0.95, green: 0.35, blue: 0.31)),
            PolyFace(vertices: [rear[0], rear[1], front[1], front[0]], color: Color(red: 0.92, green: 0.64, blue: 0.28)),
            PolyFace(vertices: [rear[1], rear[2], front[2], front[1]], color: Color(red: 0.53, green: 0.68, blue: 0.91)),
            PolyFace(vertices: [rear[2], rear[3], front[3], front[2]], color: Color(red: 0.48, green: 0.72, blue: 0.62)),
            PolyFace(vertices: [rear[3], rear[0], front[0], front[3]], color: Color(red: 0.76, green: 0.46, blue: 0.55))
        ]
    }

    private func project(_ vertex: PolyVertex, yaw: Double, pitch: Double, roll: Double, size: CGSize) -> (point: CGPoint, depth: Double) {
        let cosPitch = cos(pitch), sinPitch = sin(pitch)
        let cosYaw = cos(yaw), sinYaw = sin(yaw)
        let cosRoll = cos(roll), sinRoll = sin(roll)

        let y1 = vertex.y * cosPitch - vertex.z * sinPitch
        let z1 = vertex.y * sinPitch + vertex.z * cosPitch
        let x2 = vertex.x * cosYaw + z1 * sinYaw
        let z2 = -vertex.x * sinYaw + z1 * cosYaw
        let x3 = x2 * cosRoll - y1 * sinRoll
        let y3 = x2 * sinRoll + y1 * cosRoll
        let cameraDistance = 520.0
        let perspective = cameraDistance / max(120, cameraDistance - z2)
        let scale = Double(min(size.width, size.height)) / 250.0
        let projectedX = CGFloat(x3 * perspective * scale)
        let projectedY = CGFloat(y3 * perspective * scale)
        return (
            CGPoint(x: size.width / 2 + projectedX, y: size.height / 2 + projectedY),
            z2
        )
    }
}

private struct PolyVertex {
    let x: Double
    let y: Double
    let z: Double
}

private struct PolyFace {
    let vertices: [PolyVertex]
    let color: Color
}

private struct ProjectedFace {
    let points: [CGPoint]
    let depth: Double
    let color: Color
}

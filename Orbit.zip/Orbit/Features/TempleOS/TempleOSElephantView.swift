import SwiftUI

struct TempleOSElephantView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var isWalking = true

    private let tune = TempleOSMusicSequence(
        notes: ["G5", "E5", "C5", "G4", "A5", "F5", "C5", "D5", "F4", "B4"],
        tempo: 112
    )

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "figure.walk")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                VStack(alignment: .leading, spacing: 3) {
                    Text("ELEPHANT WALK")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(1.1)
                    Text("TempleOS-style low-resolution sprite scene")
                        .font(.system(size: 10))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button(isWalking ? "Pause" : "Walk") { isWalking.toggle() }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                TempleOSMusicPlaybackButton(sequence: tune)
                Button("Done") { dismiss() }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
            }
            .padding(16)

            TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !isWalking)) { timeline in
                Canvas { context, size in
                    var art = context
                    drawPixelScene(context: &art, size: size, time: timeline.date.timeIntervalSinceReferenceDate)
                }
            }
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .padding(.horizontal, 16)

            Text("TempleOS-style ElephantWalk scene · pixel-stepped sprite · opt-in demo tune")
                .font(.system(size: 10, design: .monospaced))
                .foregroundStyle(.secondary)
                .padding(14)
        }
        .padding(8)
        .frame(minWidth: 620, minHeight: 470)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
    }

    private func drawPixelScene(context: inout GraphicsContext, size: CGSize, time: Double) {
        let columns: CGFloat = 96
        let rows: CGFloat = 54
        let scale = min(size.width / columns, size.height / rows)
        let sceneSize = CGSize(width: columns * scale, height: rows * scale)
        context.translateBy(x: (size.width - sceneSize.width) / 2, y: (size.height - sceneSize.height) / 2)
        context.scaleBy(x: scale, y: scale)

        let sky = Color(red: 0.30, green: 0.76, blue: 0.82)
        let ground = Color(red: 0.89, green: 0.72, blue: 0.20)
        let outline = Color(red: 0.16, green: 0.18, blue: 0.20)
        let elephant = Color(red: 0.56, green: 0.58, blue: 0.59)
        let leaf = Color(red: 0.24, green: 0.56, blue: 0.28)
        let leafLight = Color(red: 0.39, green: 0.70, blue: 0.31)

        context.fill(Path(CGRect(x: 0, y: 0, width: 96, height: 54)), with: .color(sky))
        fillPixelRect((x: 0, y: 20, width: 96, height: 34), color: ground, context: &context)
        fillPixelRect((x: 0, y: 19, width: 96, height: 1), color: Color(red: 0.69, green: 0.62, blue: 0.24), context: &context)

        // The original walk scene has a simple horizon, sparse plants, and a cut branch.
        fillPixelRect((x: 8, y: 16, width: 1, height: 10), color: Color(red: 0.48, green: 0.30, blue: 0.16), context: &context)
        fillRuns([(16, 6, 8), (17, 5, 7), (18, 6, 8), (18, 9, 10), (19, 7, 9)], color: leaf, context: &context)
        fillRuns([(46, 11, 12), (45, 12, 12), (47, 13, 15), (46, 15, 15)], color: leaf, context: &context)
        fillRuns([(46, 78, 84), (45, 82, 88), (44, 86, 90), (46, 87, 91)], color: Color(red: 0.42, green: 0.29, blue: 0.17), context: &context)
        fillPixelRect((x: 89, y: 43, width: 2, height: 2), color: Color(red: 0.32, green: 0.22, blue: 0.14), context: &context)

        // Scale the sprite independently of the landscape to match the original centered ElephantWalk figure.
        var elephantArt = context
        elephantArt.translateBy(x: 23, y: 0)
        elephantArt.scaleBy(x: 0.5, y: 1)

        // Tail and legs are drawn behind the body; animation shifts each leg by one pixel row.
        fillRuns([(17, 62, 62), (18, 64, 64), (19, 65, 65), (20, 66, 66), (21, 67, 67), (22, 68, 68), (23, 68, 69)], color: outline, context: &elephantArt)
        let stride = isWalking ? Int((sin(time * 5.2) * 1.2).rounded()) : 0
        let legXs = [31 + stride, 39 - stride, 51 - stride, 59 + stride]
        for x in legXs {
            fillPixelRect((x: x, y: 27, width: 8, height: 13), color: outline, context: &elephantArt)
            fillPixelRect((x: x + 1, y: 28, width: 6, height: 11), color: elephant, context: &elephantArt)
        }

        let bodyOutline = [
            (14, 37, 51), (15, 33, 57), (16, 30, 61), (17, 28, 63), (18, 27, 65),
            (19, 26, 66), (20, 26, 67), (21, 26, 67), (22, 27, 67), (23, 28, 66),
            (24, 29, 65), (25, 30, 64), (26, 31, 63), (27, 33, 61), (28, 36, 58), (29, 40, 55)
        ]
        fillRuns(bodyOutline, color: outline, context: &elephantArt)
        fillRuns([
            (14, 38, 50), (15, 34, 56), (16, 31, 60), (17, 29, 62), (18, 28, 64),
            (19, 27, 65), (20, 27, 66), (21, 27, 66), (22, 28, 66), (23, 29, 65),
            (24, 30, 64), (25, 31, 63), (26, 32, 62), (27, 34, 60), (28, 37, 57), (29, 41, 54)
        ], color: elephant, context: &elephantArt)

        let earOutline = [(16, 31, 43), (17, 29, 45), (18, 28, 46), (19, 28, 46), (20, 28, 45), (21, 29, 44), (22, 30, 43), (23, 31, 42), (24, 33, 41), (25, 35, 40)]
        fillRuns(earOutline, color: outline, context: &elephantArt)
        fillRuns([(17, 32, 42), (18, 30, 44), (19, 29, 44), (20, 29, 43), (21, 30, 42), (22, 31, 41), (23, 32, 40), (24, 34, 39)], color: elephant, context: &elephantArt)
        fillRuns([(18, 34, 40), (19, 32, 42), (20, 31, 41), (21, 32, 40), (22, 34, 39)], color: outline, context: &elephantArt)

        let headOutline = [(11, 27, 35), (12, 23, 38), (13, 21, 39), (14, 19, 40), (15, 18, 40), (16, 17, 40), (17, 16, 40), (18, 16, 40), (19, 16, 39), (20, 17, 39), (21, 18, 39), (22, 20, 40), (23, 22, 41), (24, 26, 42)]
        fillRuns(headOutline, color: outline, context: &elephantArt)
        fillRuns([(12, 25, 36), (13, 22, 38), (14, 20, 39), (15, 19, 39), (16, 18, 39), (17, 17, 39), (18, 17, 39), (19, 17, 38), (20, 18, 38), (21, 19, 38), (22, 21, 39), (23, 23, 40)], color: elephant, context: &elephantArt)

        let trunkOutline = [(20, 16, 20), (21, 13, 18), (22, 10, 16), (23, 8, 14), (24, 8, 13), (25, 9, 13), (26, 10, 14), (27, 11, 15), (28, 12, 16), (29, 13, 17), (30, 14, 18), (31, 15, 19), (32, 16, 20), (33, 17, 21)]
        fillRuns(trunkOutline, color: outline, context: &elephantArt)
        fillRuns([(21, 14, 17), (22, 11, 15), (23, 9, 13), (24, 9, 12), (25, 10, 12), (26, 11, 13), (27, 12, 14), (28, 13, 15), (29, 14, 16), (30, 15, 17), (31, 16, 18), (32, 17, 19)], color: elephant, context: &elephantArt)

        // Tiny eye and the sprig the trunk reaches toward; no tusk is drawn in this sprite.
        fillPixelRect((x: 19, y: 16, width: 2, height: 2), color: outline, context: &elephantArt)
        fillRuns([(35, 16, 16), (34, 15, 15), (35, 19, 19), (36, 14, 14)], color: leaf, context: &elephantArt)
        fillRuns([(33, 14, 15), (34, 17, 18), (34, 20, 21), (35, 12, 13)], color: leafLight, context: &elephantArt)
        fillPixelRect((x: 16, y: 36, width: 3, height: 2), color: Color(red: 0.42, green: 0.28, blue: 0.16), context: &elephantArt)
    }

    private func fillRuns(_ runs: [(Int, Int, Int)], color: Color, context: inout GraphicsContext) {
        for (row, start, end) in runs where end >= start {
            let rect = CGRect(x: CGFloat(start), y: CGFloat(row), width: CGFloat(end - start + 1), height: 1)
            context.fill(Path(rect), with: .color(color))
        }
    }

    private func fillPixelRect(_ rect: (x: Int, y: Int, width: Int, height: Int), color: Color, context: inout GraphicsContext) {
        let path = Path(CGRect(x: CGFloat(rect.x), y: CGFloat(rect.y), width: CGFloat(rect.width), height: CGFloat(rect.height)))
        context.fill(path, with: .color(color))
    }
}

import SwiftUI
import OrbitCore

struct TempleOSBSplineView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var controlPoints: [CGPoint] = []
    @State private var isFinished = false

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "scribble.variable")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
                VStack(alignment: .leading, spacing: 3) {
                    Text("B-SPLINE DEMO")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(1.1)
                    Text("Click up to 16 control points, then finish the curve")
                        .font(.system(size: 10))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button("Finish") { isFinished = true }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
                    .disabled(controlPoints.count < 4 || isFinished)
                Button("Clear") {
                    controlPoints.removeAll()
                    isFinished = false
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                Button("Done") { dismiss() }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
            }
            .padding(16)

            Canvas { context, size in
                for step in 0...Int(size.width / 36) {
                    let x = CGFloat(step) * 36
                    var line = Path()
                    line.move(to: CGPoint(x: x, y: 0))
                    line.addLine(to: CGPoint(x: x, y: size.height))
                    context.stroke(line, with: .color(.white.opacity(0.045)), lineWidth: 1)
                }
                for step in 0...Int(size.height / 36) {
                    let y = CGFloat(step) * 36
                    var line = Path()
                    line.move(to: CGPoint(x: 0, y: y))
                    line.addLine(to: CGPoint(x: size.width, y: y))
                    context.stroke(line, with: .color(.white.opacity(0.045)), lineWidth: 1)
                }

                if controlPoints.count > 1 {
                    var controlPath = Path()
                    controlPath.move(to: controlPoints[0])
                    for point in controlPoints.dropFirst() { controlPath.addLine(to: point) }
                    context.stroke(controlPath, with: .color(.white.opacity(0.42)), style: StrokeStyle(lineWidth: 1, dash: [4, 4]))
                }

                if isFinished, controlPoints.count >= 4 {
                    let corePoints = controlPoints.map { OrbitPoint2D(x: Double($0.x), y: Double($0.y)) }
                    let splinePoints = TempleOSBSpline.curve(controlPoints: corePoints, samplesPerSegment: 28)
                    if let first = splinePoints.first {
                        var spline = Path()
                        spline.move(to: CGPoint(x: CGFloat(first.x), y: CGFloat(first.y)))
                        for point in splinePoints.dropFirst() {
                            spline.addLine(to: CGPoint(x: CGFloat(point.x), y: CGFloat(point.y)))
                        }
                        context.stroke(spline, with: .color(Color(red: 0.95, green: 0.36, blue: 0.30)), style: StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round))
                        context.stroke(spline, with: .color(Color(red: 0.28, green: 0.63, blue: 0.98)), style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                    }
                }

                for (index, point) in controlPoints.enumerated() {
                    let dot = CGRect(x: point.x - 6, y: point.y - 6, width: 12, height: 12)
                    context.fill(Path(ellipseIn: dot), with: .color(Color(red: 0.43, green: 0.86, blue: 0.67)))
                    context.stroke(Path(ellipseIn: dot), with: .color(.white.opacity(0.85)), lineWidth: 1)
                    context.draw(Text("\(index + 1)").font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundColor(.white), at: CGPoint(x: point.x, y: point.y - 15))
                }
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onEnded { value in
                        guard !isFinished, controlPoints.count < 16 else { return }
                        controlPoints.append(value.location)
                    }
            )
            .background(Color(red: 0.075, green: 0.09, blue: 0.12))
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .padding(.horizontal, 16)

            HStack(spacing: 18) {
                Label("2D B-spline · red", systemImage: "line.diagonal")
                Label("3D B-spline · blue", systemImage: "cube.transparent")
                Text("\(controlPoints.count)/16 points")
            }
            .font(.system(size: 10, design: .monospaced))
            .foregroundStyle(.secondary)
            .padding(14)
        }
        .padding(8)
        .frame(minWidth: 620, minHeight: 470)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
    }
}

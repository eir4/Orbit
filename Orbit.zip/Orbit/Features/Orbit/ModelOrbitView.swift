import AppKit
import SwiftUI
import UniformTypeIdentifiers
import OrbitCore

enum ModelOrbitLayout: Equatable {
    case compact
    case centered
    case wave
}

struct ModelOrbitView<CenterContent: View>: View {
    @EnvironmentObject private var state: OrbitAppState
    @State private var iconTargetID: String?
    @State private var showIconImporter = false

    private let layout: ModelOrbitLayout
    private let centerContent: CenterContent

    init(layout: ModelOrbitLayout, @ViewBuilder centerContent: () -> CenterContent) {
        self.layout = layout
        self.centerContent = centerContent()
    }

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                TimelineView(.animation(minimumInterval: 1 / 30, paused: false)) { timeline in
                    let time = timeline.date.timeIntervalSinceReferenceDate
                    ZStack {
                        if layout != .wave {
                            let diameter: CGFloat = layout == .centered ? 600 : 270
                            Circle()
                                .stroke(Color(red: 0.82, green: 0.77, blue: 0.73).opacity(0.55), style: StrokeStyle(lineWidth: 1, dash: [2, 7]))
                                .frame(width: diameter, height: diameter)
                            Circle()
                                .trim(from: 0.02, to: 0.12)
                                .stroke(Color(red: 0.65, green: 0.45, blue: 0.51).opacity(0.8), style: StrokeStyle(lineWidth: 2, lineCap: .round))
                                .frame(width: diameter, height: diameter)
                                .rotationEffect(.radians(rotationAngle(at: time)))
                        }
                        orbitButtons(time: time, availableWidth: geometry.size.width)
                    }
                }
                centerContent
            }
            .frame(width: geometry.size.width, height: geometry.size.height, alignment: .center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .fileImporter(isPresented: $showIconImporter, allowedContentTypes: [.image], allowsMultipleSelection: false) { result in
            guard let iconTargetID,
                  case .success(let urls) = result,
                  let url = urls.first,
                  let model = state.models.first(where: { $0.id == iconTargetID }) else { return }
            state.setCustomIcon(from: url, for: model)
        }
        .accessibilityElement(children: .contain)
    }

    private func rotationAngle(at time: Double) -> Double {
        2 * Double.pi * (time.truncatingRemainder(dividingBy: 120) / 120)
    }

    private func orbitButtons(time: Double, availableWidth: CGFloat) -> some View {
        ZStack {
            ForEach(Array(state.models.enumerated()), id: \.element.id) { index, model in
                let count = max(state.models.count, 1)
                let point = position(index: index, count: count, time: time, availableWidth: availableWidth)
                let glow = highlight(for: model, index: index, count: count, time: time)
                let appearance = state.appearance(for: model)
                ModelNode(
                    model: model,
                    appearance: appearance,
                    isDirect: state.directModelID == model.id,
                    highlight: glow,
                    isDisabled: state.isBusy,
                    compact: layout == .wave
                ) {
                    state.useDirectModel(model)
                }
                .contextMenu {
                    Button("Make coordinator") { state.setMainModel(model) }
                    Menu("Description") {
                        ForEach(ModelAppearance.descriptions, id: \.self) { description in
                            Button(description) { state.setDescription(description, for: model) }
                        }
                    }
                    Menu("Default SF Symbol") {
                        ForEach(ModelAppearance.symbols, id: \.self) { symbol in
                            Button {
                                state.setSymbol(symbol, for: model)
                            } label: {
                                Label(symbol, systemImage: symbol)
                            }
                        }
                    }
                    Button("Choose image icon…") {
                        iconTargetID = model.id
                        showIconImporter = true
                    }
                    if appearance.customImagePath != nil {
                        Button("Use SF Symbol instead") { state.clearCustomIcon(for: model) }
                    }
                }
                .offset(x: CGFloat(point.x), y: CGFloat(point.y))
            }
        }
    }

    private func position(index: Int, count: Int, time: Double, availableWidth: CGFloat) -> OrbitPosition {
        switch layout {
        case .centered:
            return OrbitMotion.position(index: index, count: count, time: time, radius: 300)
        case .compact:
            let radius = min(144, max(112, Double(count) * 30))
            return OrbitMotion.position(index: index, count: count, time: time, radius: radius)
        case .wave:
            let usableWidth = max(0, Double(availableWidth) - 80)
            let spacing = count > 1 ? min(110, usableWidth / Double(count - 1)) : 0
            return OrbitMotion.wavePosition(index: index, count: count, time: time, spacing: spacing, amplitude: 18)
        }
    }

    private func highlight(for model: LocalModel, index: Int, count: Int, time: Double) -> Double {
        guard state.isBusy, let activeModelID = state.activeModelID else { return 0 }
        if state.coordinatorIsThinking, activeModelID == state.mainModelID {
            return OrbitMotion.coordinatorPulse(index: index, count: count, time: time)
        }
        return model.id == activeModelID ? OrbitMotion.breathingPulse(time: time, phase: Double(index) * 0.42) : 0.025
    }
}

private struct ModelNode: View {
    let model: LocalModel
    let appearance: ModelAppearance
    let isDirect: Bool
    let highlight: Double
    let isDisabled: Bool
    let compact: Bool
    let action: () -> Void

    var body: some View {
        let iconSize: CGFloat = compact ? 32 : 40
        let nodeWidth: CGFloat = compact ? 52 : 132
        Button(action: action) {
            VStack(spacing: compact ? 0 : 4) {
                icon
                    .frame(width: iconSize, height: iconSize)
                    .background(isDirect ? Color(red: 0.93, green: 0.87, blue: 0.88) : .white, in: Circle())
                    .overlay(Circle().stroke(isDirect ? Color(red: 0.56, green: 0.39, blue: 0.45) : Color.black.opacity(0.09), lineWidth: isDirect ? 1.5 : 1))
                    .overlay {
                        Circle()
                            .stroke(Color(red: 0.65, green: 0.45, blue: 0.51).opacity(highlight * 0.9), lineWidth: 2)
                            .blur(radius: 4)
                            .scaleEffect(1 + 0.15 * highlight)
                    }
                    .shadow(color: Color(red: 0.65, green: 0.45, blue: 0.51).opacity(highlight * 0.35), radius: 11 * highlight)
                if !compact {
                    Text(appearance.shortDescription)
                        .font(.system(size: 8, weight: .medium, design: .monospaced))
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                        .foregroundStyle(.primary)
                        .frame(width: 116)
                }
            }
            .frame(width: nodeWidth, height: compact ? 50 : 68)
            .contentShape(Rectangle())
            .scaleEffect(1 + 0.035 * highlight)
            .opacity(isDisabled && highlight == 0 ? 0.55 : 1)
        }
        .buttonStyle(.plain)
        .disabled(isDisabled)
        .help("Tap to use this model directly. Right-click to customize its icon and description.")
        .accessibilityLabel("\(appearance.shortDescription), local model. Tap for direct chat.")
    }

    @ViewBuilder private var icon: some View {
        if let path = appearance.customImagePath, let image = NSImage(contentsOfFile: path) {
            Image(nsImage: image)
                .resizable()
                .scaledToFill()
                .clipShape(Circle())
        } else {
            Image(systemName: appearance.symbolName)
                .font(.system(size: 17, weight: .medium))
                .foregroundStyle(Color(red: 0.51, green: 0.35, blue: 0.40))
        }
    }
}

import SwiftUI
import OrbitCore

struct HexInspectorView: View {
    let attachment: PreparedAttachment
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text(attachment.name).font(.system(size: 15, weight: .semibold))
                    Text(attachment.summary).font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary)
                }
                Spacer()
                Button("Done") { dismiss() }.keyboardShortcut(.cancelAction)
            }
            Divider()
            ScrollView([.vertical, .horizontal]) {
                Text(attachment.text.isEmpty ? "No bytes to display." : attachment.text)
                    .font(.system(size: 11, weight: .regular, design: .monospaced))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12)
            }
            .background(.white, in: RoundedRectangle(cornerRadius: 10))
            Text("Read-only preview · first 4 KB · offset and ASCII columns shown")
                .font(.system(size: 9, design: .monospaced))
                .foregroundStyle(.secondary)
        }
        .padding(18)
        .background(Color(red: 0.973, green: 0.961, blue: 0.945))
    }
}

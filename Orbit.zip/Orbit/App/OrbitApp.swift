import SwiftUI

@main
struct OrbitApp: App {
    @StateObject private var state = OrbitAppState()

    var body: some Scene {
        WindowGroup {
            OrbitView()
                .environmentObject(state)
                .preferredColorScheme(.light)
        }
        .windowStyle(.titleBar)
        .defaultSize(width: 980, height: 820)
    }
}

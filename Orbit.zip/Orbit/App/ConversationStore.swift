import Foundation
import OrbitCore

public struct ConversationStore: Sendable {
    private let fileURL: URL

    public init(fileManager: FileManager = .default) {
        let root = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first ?? fileManager.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support")
        fileURL = root.appendingPathComponent("Orbit/conversations.json")
    }

    public func load() -> [ConversationRecord] {
        guard let data = try? Data(contentsOf: fileURL),
              let records = try? JSONDecoder().decode([ConversationRecord].self, from: data) else { return [] }
        return records.sorted {
            if $0.isArchived != $1.isArchived { return !$0.isArchived }
            if $0.isPinned != $1.isPinned { return $0.isPinned }
            return $0.updatedAt > $1.updatedAt
        }
    }

    public func save(_ records: [ConversationRecord]) {
        do {
            try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(records).write(to: fileURL, options: .atomic)
        } catch {
            NSLog("Orbit couldn't save conversation history: %@", error.localizedDescription)
        }
    }
}

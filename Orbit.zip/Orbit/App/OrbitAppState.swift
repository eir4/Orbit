import Combine
import Foundation
import OrbitCore

@MainActor
public final class OrbitAppState: ObservableObject {
    @Published public private(set) var models: [LocalModel] = []
    @Published public var mainModelID: String = UserDefaults.standard.string(forKey: "orbit.mainModelID") ?? ""
    @Published public var directModelID: String?
    @Published public var prompt = ""
    @Published public var messages: [ConversationEntry] = []
    @Published public private(set) var conversations: [ConversationRecord] = []
    @Published public private(set) var tasks: [OrbitTask] = []
    @Published public private(set) var currentAttachments: [PreparedAttachment] = []
    @Published public private(set) var pendingAttachments: [PreparedAttachment] = []
    @Published private(set) var appearances: [String: ModelAppearance] = [:]
    @Published public private(set) var connectionStatus = "SCANNING LOCAL MODELS"
    @Published public private(set) var isBusy = false
    @Published public private(set) var activeModelID: String?
    @Published public private(set) var coordinatorIsThinking = false
    @Published public var errorMessage: String?

    public static let modelDescriptions = ModelAppearance.descriptions
    public static let iconSymbols = ModelAppearance.symbols

    private let runtime = LocalMLXRuntime()
    private let store = ConversationStore()
    private var currentConversationID: UUID?
    private var currentTaskID: UUID?

    public init() {
        if let data = UserDefaults.standard.data(forKey: "orbit.modelAppearances"),
           let saved = try? JSONDecoder().decode([String: ModelAppearance].self, from: data) {
            appearances = saved
        }
        conversations = store.load().sorted(by: Self.conversationOrder)
        if let first = conversations.first(where: { !$0.isArchived }) {
            currentConversationID = first.id
            messages = first.entries
        }
    }

    public var mainModel: LocalModel? { models.first { $0.id == mainModelID } }
    public var directModel: LocalModel? { models.first { $0.id == directModelID } }
    public var activeConversations: [ConversationRecord] { conversations.filter { !$0.isArchived }.sorted(by: Self.conversationOrder) }
    public var archivedConversations: [ConversationRecord] { conversations.filter(\.isArchived).sorted(by: Self.conversationOrder) }
    public var completedTaskCount: Int { tasks.filter { $0.status == .completed }.count }
    public var attachmentForPanel: PreparedAttachment? {
        ConversationAttachmentPanel.preferred(pending: pendingAttachments, current: currentAttachments)
    }

    func appearance(for model: LocalModel) -> ModelAppearance {
        appearances[model.id] ?? ModelAppearance.defaultAppearance(for: model.id)
    }

    public func refreshModels() async {
        connectionStatus = "SCANNING LOCAL MODELS"
        let discovered = await runtime.discoverModels()
        models = discovered.map { model in
            var model = model
            model.role = appearance(for: model).shortDescription
            return model
        }
        if !models.contains(where: { $0.id == mainModelID }) {
            mainModelID = models.first(where: { $0.id.lowercased().contains("raptor-0.6-4b-jang_4m") })?.id ?? models.first?.id ?? ""
        }
        UserDefaults.standard.set(mainModelID, forKey: "orbit.mainModelID")
        let overBudgetCount = await runtime.overBudgetModelCount
        if overBudgetCount == 0 {
            connectionStatus = models.isEmpty ? "NO LOCAL MODELS FOUND" : "LOCAL · \(models.count) MODELS"
        } else if models.isEmpty {
            connectionStatus = "0 READY · \(overBudgetCount) OVER MEMORY"
        } else {
            connectionStatus = "LOCAL · \(models.count) READY · \(overBudgetCount) OVER MEMORY"
        }
    }

    public func setMainModel(_ model: LocalModel) {
        mainModelID = model.id
        directModelID = nil
        UserDefaults.standard.set(model.id, forKey: "orbit.mainModelID")
    }

    public func useDirectModel(_ model: LocalModel) { directModelID = model.id }
    public func returnToSquad() { directModelID = nil }

    public func setDescription(_ value: String, for model: LocalModel) {
        var appearance = appearance(for: model)
        appearance.shortDescription = value
        saveAppearance(appearance, for: model)
        models = models.map { item in
            var item = item
            if item.id == model.id { item.role = value }
            return item
        }
    }

    public func setSymbol(_ symbol: String, for model: LocalModel) {
        var appearance = appearance(for: model)
        appearance.symbolName = symbol
        saveAppearance(appearance, for: model)
    }

    public func setCustomIcon(from source: URL, for model: LocalModel) {
        let hasAccess = source.startAccessingSecurityScopedResource()
        defer { if hasAccess { source.stopAccessingSecurityScopedResource() } }
        do {
            let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
                .appendingPathComponent("Orbit/icons", isDirectory: true)
            try FileManager.default.createDirectory(at: support, withIntermediateDirectories: true)
            let safeName = model.id.replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: " ", with: "_")
            let destination = support.appendingPathComponent("\(safeName)-\(UUID().uuidString).\(source.pathExtension)")
            try FileManager.default.copyItem(at: source, to: destination)
            var appearance = appearance(for: model)
            appearance.customImagePath = destination.path
            saveAppearance(appearance, for: model)
        } catch {
            errorMessage = "Couldn't save that icon: \(error.localizedDescription)"
        }
    }

    public func clearCustomIcon(for model: LocalModel) {
        var appearance = appearance(for: model)
        if let path = appearance.customImagePath { try? FileManager.default.removeItem(atPath: path) }
        appearance.customImagePath = nil
        saveAppearance(appearance, for: model)
    }

    private func saveAppearance(_ appearance: ModelAppearance, for model: LocalModel) {
        appearances[model.id] = appearance
        if let data = try? JSONEncoder().encode(appearances) {
            UserDefaults.standard.set(data, forKey: "orbit.modelAppearances")
        }
    }

    public func addAttachments(_ urls: [URL]) async {
        for url in urls {
            do {
                pendingAttachments.append(try AttachmentService.prepare(url))
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    public func removeAttachment(_ attachment: PreparedAttachment) {
        pendingAttachments.removeAll { $0.id == attachment.id }
    }

    public func stageAttachmentForResend(_ attachment: PreparedAttachment) {
        guard !pendingAttachments.contains(where: { $0.id == attachment.id }) else { return }
        pendingAttachments.append(attachment)
    }

    public func startNewConversation() {
        currentConversationID = nil
        messages = []
        tasks = []
        currentAttachments = []
        pendingAttachments = []
        currentTaskID = nil
        directModelID = nil
        prompt = ""
    }

    public func openConversation(_ conversation: ConversationRecord) {
        guard !conversation.isArchived else { return }
        currentConversationID = conversation.id
        messages = conversation.entries
        tasks = []
        currentAttachments = []
        pendingAttachments = []
        currentTaskID = nil
        directModelID = nil
    }

    public func generateGodWord() {
        guard !isBusy else { return }
        do {
            let output = try TempleOSGodWordTool().execute(arguments: [:])
            receive(.invoked(name: "templeos_god_word", arguments: "{}"))
            receive(.result(name: "templeos_god_word", output: output))
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    public func setPinned(_ pinned: Bool, for conversationID: UUID) {
        guard !isBusy, let index = conversations.firstIndex(where: { $0.id == conversationID }) else { return }
        conversations[index].isPinned = pinned
        saveConversations()
    }

    public func archiveConversation(_ conversationID: UUID) {
        guard !isBusy, let index = conversations.firstIndex(where: { $0.id == conversationID }) else { return }
        conversations[index].isArchived = true
        if currentConversationID == conversationID { clearCurrentConversation() }
        saveConversations()
    }

    public func unarchiveConversation(_ conversationID: UUID) {
        guard let index = conversations.firstIndex(where: { $0.id == conversationID }) else { return }
        conversations[index].isArchived = false
        saveConversations()
    }

    public func deleteConversation(_ conversationID: UUID) {
        guard !isBusy else { return }
        conversations.removeAll { $0.id == conversationID }
        if currentConversationID == conversationID { clearCurrentConversation() }
        saveConversations()
    }

    @discardableResult
    public func importArchivedText(_ text: String) throws -> UUID {
        var record = try ConversationArchiveCodec.decode(text)
        if conversations.contains(where: { $0.id == record.id }) { record.id = UUID() }
        record.isPinned = false
        record.isArchived = false
        conversations.append(record)
        currentConversationID = record.id
        messages = record.entries
        tasks = []
        currentAttachments = []
        pendingAttachments = []
        currentTaskID = nil
        directModelID = nil
        saveConversations()
        return record.id
    }

    private func clearCurrentConversation() {
        currentConversationID = nil
        messages = []
        tasks = []
        currentAttachments = []
        directModelID = nil
        prompt = ""
        pendingAttachments = []
        currentTaskID = nil
    }

    private func saveConversations() {
        conversations.sort(by: Self.conversationOrder)
        store.save(conversations)
    }

    public func send() {
        let userText = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard (!userText.isEmpty || !pendingAttachments.isEmpty), !isBusy else { return }
        let attachments = pendingAttachments
        pendingAttachments = []
        currentAttachments = attachments
        tasks = []
        currentTaskID = nil
        prompt = ""
        let attachmentNames = attachments.map(\.name)
        let messageText = [userText, attachmentNames.isEmpty ? nil : "Attached: " + attachmentNames.joined(separator: ", ")]
            .compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: "\n")
        append(ConversationEntry(kind: .user, text: messageText))
        isBusy = true
        activeModelID = directModelID ?? mainModelID
        coordinatorIsThinking = directModelID == nil
        errorMessage = nil

        Task { [weak self] in
            guard let self else { return }
            do {
                let toolClient = ToolAwareModelClient(baseClient: self.runtime, onEvent: { [weak self] event in
                    await self?.receive(event)
                })
                if let directModel = self.directModel {
                    let context = Self.directPrompt(userText, attachments: attachments)
                    let result = try await toolClient.complete(
                        modelID: directModel.id,
                        system: "You are a helpful local assistant. Be clear about what the attached files show and what you cannot determine.",
                        user: context,
                        images: attachments.compactMap(\.imageDataURL)
                    )
                    self.append(ConversationEntry(kind: .assistant, text: result, modelID: directModel.id))
                } else if let main = self.mainModel {
                    let workers = self.models.filter { $0.id != main.id }
                    let runner = TurnOrchestrator(client: toolClient, onEvent: { [weak self] event in
                        await self?.receive(event)
                    })
                    _ = try await runner.run(prompt: userText, mainModel: main, specialistModels: workers, attachments: attachments)
                } else {
                    throw LocalRuntimeError.modelNotFound("Choose a coordinator model")
                }
            } catch {
                self.append(ConversationEntry(kind: .assistant, text: "Local run stopped: \(error.localizedDescription)"))
            }
            self.isBusy = false
            self.activeModelID = nil
            self.coordinatorIsThinking = false
        }
    }

    private func receive(_ event: OrchestrationEvent) {
        switch event {
        case .mainThinking:
            activeModelID = mainModelID
            coordinatorIsThinking = true
            append(ConversationEntry(kind: .activity, text: "Main model reviewing the goal and results…"))
        case .delegated(let modelID, let task):
            activeModelID = modelID
            coordinatorIsThinking = false
            let orbitTask = OrbitTask(title: task, modelID: modelID, status: .inProgress, createdAt: .now, startedAt: .now)
            tasks.append(orbitTask)
            currentTaskID = orbitTask.id
            append(ConversationEntry(kind: .activity, text: "Next · \(displayName(for: modelID))\n\(task)", modelID: modelID))
        case .specialistResult(let modelID, let result):
            if let currentTaskID, let index = tasks.firstIndex(where: { $0.id == currentTaskID }) {
                tasks[index].status = .completed
                tasks[index].completedAt = .now
            }
            currentTaskID = nil
            activeModelID = mainModelID
            coordinatorIsThinking = true
            append(ConversationEntry(kind: .specialist, text: result, modelID: modelID))
        case .completed(let answer):
            activeModelID = nil
            coordinatorIsThinking = false
            currentTaskID = nil
            append(ConversationEntry(kind: .assistant, text: answer, modelID: mainModelID))
        }
    }

    private func receive(_ event: OrbitToolEvent) {
        switch event {
        case .invoked(let name, let arguments):
            append(ConversationEntry(kind: .activity, text: "Using local tool · \(name)\n\(arguments)", modelID: "tool:\(name)"))
        case .result(let name, let output):
            append(ConversationEntry(kind: .specialist, text: output, modelID: "tool:\(name)"))
        }
    }

    private func append(_ entry: ConversationEntry) {
        messages.append(entry)
        persistCurrentConversation()
    }

    private func persistCurrentConversation() {
        if let currentConversationID, let index = conversations.firstIndex(where: { $0.id == currentConversationID }) {
            conversations[index].entries = messages
            conversations[index].updatedAt = .now
        } else if !messages.isEmpty {
            let firstUser = messages.first(where: { $0.kind == .user })?.text ?? "New conversation"
            var record = ConversationRecord(title: String(firstUser.prefix(56)), entries: messages)
            record.updatedAt = .now
            conversations.insert(record, at: 0)
            currentConversationID = record.id
        }
        saveConversations()
    }

    private static func conversationOrder(_ lhs: ConversationRecord, _ rhs: ConversationRecord) -> Bool {
        if lhs.isArchived != rhs.isArchived { return !lhs.isArchived }
        if lhs.isPinned != rhs.isPinned { return lhs.isPinned }
        return lhs.updatedAt > rhs.updatedAt
    }

    private func displayName(for id: String) -> String {
        models.first(where: { $0.id == id })?.displayName ?? id
    }

    private static func directPrompt(_ prompt: String, attachments: [PreparedAttachment]) -> String {
        let contexts = attachments.map { attachment in
            "FILE \(attachment.name) [\(attachment.kind.rawValue)]\n\(attachment.text.isEmpty ? attachment.summary : attachment.text)"
        }.joined(separator: "\n\n")
        return [prompt, contexts.isEmpty ? nil : "ATTACHMENTS:\n\(contexts)"]
            .compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: "\n\n")
    }
}

import Foundation

struct ModelAppearance: Codable, Hashable, Sendable {
    var shortDescription: String
    var symbolName: String
    var customImagePath: String?

    static func defaultAppearance(for id: String) -> ModelAppearance {
        let key = id.lowercased()
        if key.contains("raptor") && key.contains("jang_4m") { return .init(shortDescription: "Planner · coding", symbolName: "brain.head.profile") }
        if key.contains("raptor") { return .init(shortDescription: "Reasoning", symbolName: "brain") }
        if key.contains("medgemma") { return .init(shortDescription: "Medical vision", symbolName: "cross.case.fill") }
        if key.contains("gemma") || key.contains("vision") || key.contains("pixtral") { return .init(shortDescription: "Image analysis", symbolName: "eye") }
        if key.contains("lfm2.5") { return .init(shortDescription: "Quick text", symbolName: "bolt.fill") }
        if key.contains("lfm2") { return .init(shortDescription: "Fast analysis", symbolName: "text.magnifyingglass") }
        return .init(shortDescription: "Specialist", symbolName: "cpu")
    }

    static let descriptions = [
        "Planner · coding",
        "Reasoning",
        "Quick text",
        "Fast analysis",
        "Image analysis",
        "Medical vision",
        "Document reading",
        "Hex inspection",
        "Specialist"
    ]

    static let symbols = [
        "brain.head.profile", "brain", "curlybraces", "bolt.fill",
        "text.magnifyingglass", "eye", "cross.case.fill",
        "doc.text.magnifyingglass", "number", "memorychip", "cpu", "sparkles"
    ]
}
